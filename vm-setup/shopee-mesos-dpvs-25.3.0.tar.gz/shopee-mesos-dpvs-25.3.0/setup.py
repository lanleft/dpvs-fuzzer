import os
import sys
from setuptools import setup
from contextlib import contextmanager
from shopee_deploy.utils import generate_file_by_template, execute


PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))


@contextmanager
def cd(path):
	old_dir = os.getcwd()
	os.chdir(path)
	try:
		yield
	finally:
		os.chdir(old_dir)


def _setup():
	with cd(PROJECT_DIR):
		install_requires = []
		for requirement in open(os.path.join('shopee_mesos_dpvs', 'requirements.txt')).readlines():
			requirement = requirement.strip()
			if len(requirement) > 0 and requirement[0] != '#':
				install_requires.append(requirement)

		# Perform install process.
		if sys.argv[1] != 'sdist':
			generate_file_by_template(
				os.path.join('shopee-mesos-dpvs-fullnat.service'),
				os.path.join(os.path.sep, 'lib', 'systemd', 'system', 'shopee-mesos-dpvs-fullnat.service'))

			generate_file_by_template(
				os.path.join('shopee-mesos-dpvs-snat.service'),
				os.path.join(os.path.sep, 'lib', 'systemd', 'system', 'shopee-mesos-dpvs-snat.service'))

			env = open('/etc/mesos-dpvs/env').read().strip()
			log_dir = '/data/log/dpvs-daemon-%s-sg/' % env
			if not os.path.exists(log_dir):
				os.makedirs(log_dir)

			if os.path.exists(os.path.join(os.path.sep, 'bin', 'systemctl')):
				execute('systemctl enable dpvs')
				# execute('systemctl start dpvs')
				# execute('systemctl enable shopee-mesos-dpvs-fullnat')
				# execute('systemctl start shopee-mesos-dpvs-fullnat')

		setup(name='shopee-mesos-dpvs',
			version=open('version').read().strip(),
			author='Shopee',
			author_email='huangh@garena.com',
			description='Shopee DPVS daemon.',
			url='ssh://gitlab@git.garena.com:2222/shopee/devops/shopee-mesos-cache.git',
			packages=['shopee_mesos_dpvs'],
			install_requires=install_requires,
			include_package_data=True,
			entry_points={'console_scripts': ['shopee-mesos-dpvs = shopee_mesos_dpvs.main:base.cli']},
		)


if __name__ == '__main__':
	_setup()
