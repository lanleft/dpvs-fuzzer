# -*- coding: UTF-8 -*-
import json
import shutil
import random
from shopee_deploy.utils import read_file, execute, write_file, generate_content_by_template, get_command_output
from .logger import log
import datetime
import os
import re
import time
import socket
from threading import Lock, Thread
import traceback
from .config import get_config
from .config_center import module_config
from .command import get_command_output_with_lock, GenericFunction
from packaging.version import Version


class Bird(object):

	CTRL_FILE = '/usr/local/var/run/bird.ctl'
	CONFIG_FILE = '/etc/bird/bird.conf'
	CONFIG_HISTORY_PREFIX = '/etc/bird/history/bird.conf'
	bird_conf_content_backup = None
	BIRD_MULTI_STAGE = '/etc/mesos-dpvs/bird_multi_stage.json'
	UDP_DETECT_PORT_START = 32
	UDP_DETECT_PORT_END   = 63

	# 先用磁盘中的本地备份配置覆盖代码中的默认配置
	bird_multi_stage_advertise = module_config.get_from_local_config("bird_multi_stage_advertise", {
																		"switch": True,
																		"detect_master_lip_packet_count": 1000,
																		"detect_slave_lip_packet_count": 100,
																		"detect_timeout": 5,
																		"success_threshold": 0.9,
																		"wait_time_before_detect_when_reload": 3,
																		"wait_time_before_detect_when_start": 20,
																		"wait_time_after_connect_to_switch": 1
																	})

	STAGE_1 = "stage1"
	STAGE_2 = "stage2"

	bird_stage1_failed_count = 0

	non_advertisable_ips = set()   # 不能被BGP发布的IP集合

	advertised_master_lips = set()
	advertised_slave_lips = set()
	advertised_vips = set()

	to_advertise_master_lips = set()
	to_advertise_slave_lips = set()
	to_advertise_vips = set()

	_lock = Lock()

	@classmethod
	def clear_advertised_ips(cls):
		cls.advertised_master_lips = set()
		cls.advertised_slave_lips = set()
		cls.advertised_vips = set()

	@classmethod
	def is_running(cls):
		content = read_file('/proc/net/unix')
		if cls.CTRL_FILE not in content:
			cls.clear_advertised_ips()
			return False
		return True

	@classmethod
	def start(cls):
		ret = execute('service bird start')
		if ret:
			log.info('start_bird_success')
		else:
			log.error('start_bird_failed')
		return ret

	@classmethod
	def stop(cls):
		ret = execute('service bird stop')
		if ret:
			cls.clear_advertised_ips()
			log.info('stop_bird_success')
		else:
			log.error('stop_bird_failed')
		return ret

	@classmethod
	def stop_with_lock(cls):
		with cls._lock:
			return cls.stop()

	@classmethod
	def reload(cls):
		ret = execute('birdcl "configure"')
		if ret:
			log.info('reload_bird_success')
		else:
			log.error('reload_bird_failed')
		return ret

	@classmethod
	def update_config_and_reload(cls, new_content):
		with cls._lock:
			existing_config = read_file(cls.CONFIG_FILE)
			Bird.bird_conf_content_backup = existing_config
			if existing_config != new_content:
				log.info('bird config file updated, old bird config: %s\n, new bird config: %s', existing_config, new_content)
				write_file(cls.CONFIG_FILE, new_content)

				if cls.is_running():
					# Reload configuration.
					if cls.reload():
						return True

			return False

	@classmethod
	def update_config(cls, new_content, timestamp=None, stage=""):
		existing_config = read_file(cls.CONFIG_FILE)
		Bird.bird_conf_content_backup = existing_config
		if existing_config != new_content:
			if timestamp is None:
				timestamp = datetime.datetime.now().strftime("%Y-%m-%d.%H%M%S")
			history_file_name_prefix = '{}.{}'.format(cls.CONFIG_HISTORY_PREFIX, timestamp)
			if stage == cls.STAGE_1:
				backup_file_name = '{}.{}'.format(history_file_name_prefix, "backup")
				write_file(backup_file_name, Bird.bird_conf_content_backup)
			if stage:
				history_file_name = '{}.{}'.format(history_file_name_prefix, stage)
				write_file(history_file_name, new_content)
				log.info('the bird config file will be updated, history_file_name: %s', history_file_name)
			write_file(cls.CONFIG_FILE, new_content)
			return True
		return False

	@classmethod
	def rollback_config(cls):
		if Bird.bird_conf_content_backup:
			write_file(cls.CONFIG_FILE, Bird.bird_conf_content_backup)

	@classmethod
	def get_and_store_param(cls):
		cls.bird_multi_stage_advertise, _ = module_config.get_precise("bird_multi_stage_advertise", cls.bird_multi_stage_advertise)

	@classmethod
	def update_statistic_result_file(cls, op):
		if "add" == op:
			cls.bird_stage1_failed_count += 1
		elif "reset" == op:
			cls.bird_stage1_failed_count = 0
		else:
			return

		temp_file = '/etc/mesos-dpvs/bird_multi_stage_%d%d' % (int(time.time()), random.randint(100000, 999999),)
		statistic_result = {"bird_stage1_failed_count": cls.bird_stage1_failed_count}
		bird_multi_stage_statistic = json.dumps(statistic_result, indent=2)
		write_file(temp_file, bird_multi_stage_statistic)
		shutil.move(temp_file, cls.BIRD_MULTI_STAGE)

	@classmethod
	def multi_stage_advertise(cls, op_type="start"):
		"""
		多阶段路由发布，第一阶段发布lip，第二阶段发布vip (Note: 实际上，会存在需要跳过某一stage的情况):
		1. 准备 STAGE_1 bgp配置
		2. 依据 STAGE_1 bgp配置，start bird 或 reload bird
		3. 计算增量lip，探测增量lip，存储最新lip
		4. 若探测lip都成功，则 准备 STAGE_2 bgp配置
		5. 依据 STAGE_2 bgp配置， reload bird
		:param op_type: start or reload
		:return: 仅在多个stage都成功时 返回 True，否则返回 False
		"""
		with cls._lock:
			# 参数校验 and 幂等性处理
			if op_type == "reload":
				log.info('begin to reload_bird in multi_stage_advertise(%s)', op_type)
				if not cls.is_running():
					log.info('bird is not running.')
					return False
			elif op_type == "start":
				log.info('begin to start_bird in multi_stage_advertise(%s)', op_type)
				if cls.is_running():
					log.info('bird is already running.')
					return True
			else:
				log.error('invalid param op_type:(%s)', op_type)
				return False

			# 获取当前时间并格式化为 YYYY-MM-DD.HHMMSS ，该时间戳代表多阶段路由发布开始时的时间快照
			timestamp = datetime.datetime.now().strftime("%Y-%m-%d.%H%M%S")
			cls.generate_ip_list_to_advertise()

			# 获取最新的参数
			cls.get_and_store_param()

			if not cls.bird_multi_stage_advertise["switch"]:   # bird_multi_stage_advertise 特性灰度开关
				config_updated = cls.update_standard_cluster_bird_config(timestamp, cls.STAGE_2)
				if op_type == "start":
					if cls.start():
						cls.advertised_master_lips = cls.to_advertise_master_lips
						cls.advertised_slave_lips = cls.to_advertise_slave_lips
						cls.advertised_vips = cls.to_advertise_vips
						return True
					else:
						cls.stop()
						return False
				elif op_type == "reload":
					if config_updated:
						if cls.reload():
							cls.advertised_master_lips = cls.to_advertise_master_lips
							cls.advertised_slave_lips = cls.to_advertise_slave_lips
							cls.advertised_vips = cls.to_advertise_vips
							return True
						return False
					else:
						log.info('the bird config file has not changed, skipping reload bird')
						return True
				else:
					return False

			# if op_type == "start":
			# 	cls.clear_advertised_ips()   # already done in cls.is_running()

			# 初次 reload（或前几次reload都失败）的场景下，在准备 STAGE_1 配置之前，先准备好 cls.advertised_vips
			first_reload_operation = False if cls.advertised_master_lips else True
			if op_type == "reload" and not cls.advertised_vips:
				ip_addresses = cls.get_advertised_vips_and_master_lips_from_config_file()
				for ip in ip_addresses:
					if ip in cls.to_advertise_vips:
						cls.advertised_vips.add(ip)

			config_updated = cls.update_standard_cluster_bird_config(timestamp, cls.STAGE_1)

			if op_type == "start" or (op_type == "reload" and config_updated) or first_reload_operation:
				if op_type == "start":
					if not cls.start():
						cls.stop()
						cls.update_statistic_result_file("add")
						return False
					if not cls.has_connect_to_switch_with_retry(cls.bird_multi_stage_advertise["wait_time_before_detect_when_start"]):
						cls.stop()
						cls.update_statistic_result_file("add")
						return False
				elif op_type == "reload":
					if not cls.reload():
						cls.rollback_config()   # 若失败，配置回滚
						cls.update_statistic_result_file("add")
						return False
					time.sleep(cls.bird_multi_stage_advertise["wait_time_before_detect_when_reload"])

				new_master_lip = list(cls.to_advertise_master_lips.difference(cls.advertised_master_lips))
				new_slave_lip = list(cls.to_advertise_slave_lips.difference(cls.advertised_slave_lips))

				detect_result = cls.detect_lip(new_master_lip, new_slave_lip)
				if detect_result:
					cls.advertised_master_lips = cls.to_advertise_master_lips
					cls.advertised_slave_lips = cls.to_advertise_slave_lips
				else:
					log.error('detect_lip failed when multi_stage_advertise(%s)', op_type)
					if op_type == "start":   # 若失败，先 stop bird，然后，由调用方重试
						cls.stop()
					elif op_type == "reload":   # 若失败，配置回滚
						cls.rollback_config()
					cls.update_statistic_result_file("add")
					return False
			elif op_type == "reload" and not config_updated:
				log.info('the bird config file has not changed, skipping reload bird in %s', cls.STAGE_1)

			# stage1 success or skip stage1
			cls.update_statistic_result_file("reset")

			config_updated = cls.update_standard_cluster_bird_config(timestamp, cls.STAGE_2)
			if config_updated:
				if cls.reload():
					cls.advertised_vips = cls.to_advertise_vips
					return True
				else:
					return False
			else:
				log.info('the bird config file has not changed, skipping reload bird in %s', cls.STAGE_2)
			return True   # 若两个阶段全部跳过，则视为成功

	@classmethod
	def has_connect_to_switch_with_retry(cls, max_timeout, try_interval=1):
		i = 0
		while i < max_timeout:
			time.sleep(try_interval)
			i = (i+1) * try_interval
			if not cls.has_connect_to_switch():
				if i < max_timeout:
					log.error('has_NOT_connect_to_switch, retrying...')
				continue
			else:
				wait_time = cls.bird_multi_stage_advertise["wait_time_after_connect_to_switch"]
				log.info('has_connect_to_switch, sleep for %ss to wait for route advertising to complete', wait_time)
				time.sleep(wait_time)
				return True
		return False

	@classmethod
	def has_connect_to_switch(cls):
		has_connect_to_lan_switch = False
		has_connect_to_wan_switch = False
		config = get_config()
		command = "netstat -antp | grep bird"
		try:
			output_str = get_command_output(command)
		except Exception as e:
			debug_msg = traceback.format_exc()
			log.error('execute_command_failed|ignoring|command=%s,traceback=%s', command, debug_msg)
			return False

		lines = output_str.split('\n')
		for line in lines:
			if config.lan_switch_ip in line and "ESTABLISHED" in line:
				has_connect_to_lan_switch = True
				break
		# if config.HAS_WAN_NIC:
		# 	for line in lines:
		# 		if config.wan_switch_ip in line and "ESTABLISHED" in line:
		# 			has_connect_to_wan_switch = True
		# 			break
		# if not config.HAS_WAN_NIC and has_connect_to_lan_switch:
		# 	return True
		# elif config.HAS_WAN_NIC and has_connect_to_lan_switch and has_connect_to_wan_switch:
		# 	return True
		# else:
		# 	log.error(
		# 		'has_connect_to_lan_switch=%s,has_connect_to_wan_switch=%s,has_wan_nic=%s',
		# 		has_connect_to_lan_switch, has_connect_to_wan_switch, config.HAS_WAN_NIC)
		# 	return False

		# Todo: remove code below and use code above When we can distinguish weather the cluster type is lan, wan or mix
		if has_connect_to_lan_switch:
			return True
		else:
			log.error('has_connect_to_lan_switch=%s', has_connect_to_lan_switch)
			return False

	@classmethod
	def generate_ip_list_to_advertise(cls):
		# get `dpip addr show` result to make sure vip/lip in dpdk nic
		fd = os.popen("dpip addr show")
		all_ip_list = re.findall(r'\d+\.\d+\.\d+\.\d+', fd.read())
		fd.close()

		config = get_config()
		master_lips = config.get_master_lips()
		all_lips = config.get_lips()
		all_vips = config.get_vips()

		to_advertise_master_lips = set()
		for master_lip in master_lips:
			if master_lip not in cls.non_advertisable_ips and master_lip in all_ip_list:
				to_advertise_master_lips.add(master_lip)

		to_advertise_slave_lips = set()
		for lip in all_lips:
			if lip not in master_lips and lip not in cls.non_advertisable_ips and lip in all_ip_list:
				to_advertise_slave_lips.add(lip)

		to_advertise_vips = set()
		for vip in all_vips:
			if vip not in cls.non_advertisable_ips and vip in all_ip_list:
				to_advertise_vips.add(vip)

		# 在外部，使用 cls._lock 加锁保护
		cls.to_advertise_master_lips = to_advertise_master_lips
		cls.to_advertise_slave_lips = to_advertise_slave_lips
		cls.to_advertise_vips = to_advertise_vips

	@classmethod
	def get_advertised_vips_and_master_lips_from_config_file(cls):
		existing_config = read_file(cls.CONFIG_FILE)
		pattern = r"route (\d+\.\d+\.\d+\.\d+)/32 via \"lo\";"
		ip_addresses = re.findall(pattern, existing_config)   # vips + master_node_lips + master_outer_lips
		return ip_addresses

	@classmethod
	def update_standard_cluster_bird_config(cls, timestamp, stage):
		config = get_config()

		bird_template_file = os.path.join(os.path.dirname(__file__), 'res', 'standard_cluster_bird_fullnat.conf.j2')
		content_map = {
			"master_lips": list(cls.advertised_master_lips),
			"slave_lips": list(cls.advertised_slave_lips),
			"vips": list(cls.advertised_vips),
			"lan_inner_ip": config.lan_inner_ip,
			"lan_switch_ip": config.lan_switch_ip,
			"lan_switch_as": config.lan_switch_as,
			"lan_local_as": config.lan_local_as,
			"bgp_keepalive_time": config.bgp_keepalive_time,
			"bgp_hold_time": config.bgp_hold_time,
			"wan_nic": config.wan_nic,
			"wan_bfd": config.wan_bfd,
			"bfd_multiplier": config.bfd_multiplier,
			"bfd_min_rx_interval": config.bfd_min_rx_interval,
			"bfd_min_tx_interval": config.bfd_min_tx_interval,
			"wan_switch_ip": config.wan_switch_ip,
			"wan_switch_as": config.wan_switch_as,
			"wan_local_as": config.wan_local_as,
			"wan_inner_ip": config.wan_inner_ip,
			"has_wan_nic": config.HAS_WAN_NIC,
		}
		if stage == cls.STAGE_1:
			content_map["master_lips"] = list(cls.to_advertise_master_lips)
			content_map["slave_lips"] = list(cls.to_advertise_slave_lips)
		elif stage == cls.STAGE_2:
			content_map["master_lips"] = list(cls.to_advertise_master_lips)
			content_map["slave_lips"] = list(cls.to_advertise_slave_lips)
			content_map["vips"] = list(cls.to_advertise_vips)
		else:
			log.error('param stage must be %s or %s', cls.STAGE_1, cls.STAGE_2)
			return False

		content = generate_content_by_template(bird_template_file, **content_map)
		return Bird.update_config(content, timestamp, stage)

	@classmethod
	def detect_lip(cls, master_lips, slave_lips):
		"""
		暂时仅对 node_lip 进行探测，忽略 outer_lip
		:param master_lips: 待BGP发布的 master_node_lip + master_outer_lip
		:param slave_lips: 待BGP发布的 slave_node_lip + slave_outer_lip
		:return: 所有 lip 都探测成功，则返回 True; 任一 lip 探测失败，则返回 False
		"""

		def ping_and_get_packet_loss_rate(ip, count, timeout=cls.bird_multi_stage_advertise["detect_timeout"]):
			command = "ping %s -f -q -c %s -w %s" % (ip, count, timeout)
			try:
				output_str = get_command_output(command)
			except Exception as e:
				debug_msg = traceback.format_exc()
				log.error('execute_command_failed|ignoring|command=%s,traceback=%s', command, debug_msg)
				return float(100)

			# 提取丢包率
			packet_loss_match = re.search(r'(\d+\.\d+|\d+)% packet loss', output_str)
			if packet_loss_match:
				packet_loss_rate = float(packet_loss_match.group(1))
				return packet_loss_rate
			else:
				log.error('Cannot find the packet loss rate in the output_str.')
				return float(100)

		def detect_by_udp_port_scan_with_retry(ip, port_start, port_end, local_ip, max_retries=3, timeout=cls.bird_multi_stage_advertise["detect_timeout"]):
			udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			udp_socket.settimeout(timeout)
			message = "lip_fdir_detect\0".encode('utf-8')
			for port in range(port_start, port_end + 1):
				retries = 0
				success = False
				while retries < max_retries and not success:
					try:
						udp_socket.sendto(message, (ip, port))
						data, _ = udp_socket.recvfrom(64)
						response = data.decode('utf-8')
						if response.startswith(local_ip):
							success = True
						else:
							retries += 1
							log.error('udp detect (%s:%d) response invalid', ip, port)
							time.sleep(1)
					except socket.timeout:
						retries += 1
						log.error('udp detect (%s:%d) time out', ip, port)
						time.sleep(1)
					except Exception as e:
						retries += 1
						log.error('udp detect (%s:%d) failed', ip, port)
						time.sleep(1)
				if not success:
					udp_socket.close()
					return False

			udp_socket.close()
			return True

		def detect_packet_loss_rate_by_udp(ip, port_start, port_end, num_packets, timeout=cls.bird_multi_stage_advertise["detect_timeout"]):
			udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			udp_socket.settimeout(timeout)
			udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024 * 1024)
			message = "lip_fdir_detect\0".encode('utf-8')
			received_count = [0]

			def send_packets():
				for _ in range(num_packets):
					port = random.randint(port_start, port_end)
					try:
						udp_socket.sendto(message, (ip, port))
						time.sleep(0.01)
					except Exception as e:
						log.error('Failed to send UDP packet to (%s:%d): %s', ip, port, e)
						break

			def receive_packets():
				while received_count[0] < num_packets:
					try:
						_, _ = udp_socket.recvfrom(1024)
						received_count[0] += 1
					except socket.timeout:
						break

			receiver = Thread(target=receive_packets)
			receiver.start()
			send_packets()
			receiver.join()

			udp_socket.close()

			loss_rate = (num_packets - received_count[0]) / float(num_packets) * 100 if num_packets > 0 else 0
			return round(loss_rate, 2)


		def get_S_ROUTE_OUT_NET_LOOKUP():
			output_str = get_command_output_with_lock('ipvsadm --sys-stats-once --total | grep S_ROUTE_OUT_NET_LOOKUP')
			match = re.search(r'S_ROUTE_OUT_NET_LOOKUP\s+(\d+)', output_str)
			if match:
				return True, int(match.group(1))
			else:
				log.error('S_ROUTE_OUT_NET_LOOKUP not found in the output_str.')
				return False, 0

		def detect_master_lip(ip):
			dpvs_version = GenericFunction.get_dpvs_version()
			if dpvs_version <= Version('25.1.0'):
				ok, stats_before = get_S_ROUTE_OUT_NET_LOOKUP()
				if ok:
					count = cls.bird_multi_stage_advertise["detect_master_lip_packet_count"]
					packet_loss_rate = ping_and_get_packet_loss_rate(ip, count)
					if packet_loss_rate/100 > 1 - cls.bird_multi_stage_advertise["success_threshold"]:
						log.error('ping %s packet_loss_rate: %s%%', ip, packet_loss_rate)
						return False
					ok, stats_after = get_S_ROUTE_OUT_NET_LOOKUP()
					if ok:
						if stats_after - stats_before >= count * cls.bird_multi_stage_advertise["success_threshold"]:
							return True
						else:
							log.error('increment of S_ROUTE_OUT_NET_LOOKUP: %s', stats_after - stats_before)
				return False
			else:
				config = get_config()
				local_ip = config.sync_session_src_ip
				if local_ip is None:
					return False
				ok = detect_by_udp_port_scan_with_retry(ip, Bird.UDP_DETECT_PORT_START, Bird.UDP_DETECT_PORT_END, local_ip)
				if ok:
					count = cls.bird_multi_stage_advertise["detect_master_lip_packet_count"]
					packet_loss_rate = detect_packet_loss_rate_by_udp(ip, Bird.UDP_DETECT_PORT_START, Bird.UDP_DETECT_PORT_END, count)
					if packet_loss_rate/100 > 1 - cls.bird_multi_stage_advertise["success_threshold"]:
						log.error('udp detect %s packet_loss_rate: %s%%', ip, packet_loss_rate)
						return False
					else:
						return True
				log.error('udp detect %s scan port failed', ip)
				return False


		def detect_slave_lip(ip):
			count = cls.bird_multi_stage_advertise["detect_slave_lip_packet_count"]
			packet_loss_rate = ping_and_get_packet_loss_rate(ip, count)
			if packet_loss_rate/100 > 1 - cls.bird_multi_stage_advertise["success_threshold"]:
				log.error('ping %s packet_loss_rate: %s%%', ip, packet_loss_rate)
				return False
			else:
				return True

		config = get_config()

		# 暂时仅对 node_lip 进行探测，忽略 outer_lip（日后择机放开）
		_master_lips = []
		for master_lip in master_lips:
			if master_lip in config.master_node_lips:
				_master_lips.append(master_lip)
		master_lips = _master_lips

		_slave_lips = []
		for slave_lip in slave_lips:
			if slave_lip in config.node_lips:
				_slave_lips.append(slave_lip)
		slave_lips = _slave_lips

		for master_lip in master_lips:
			if master_lip in config.master_node_lips:
				result = detect_master_lip(master_lip)
				if not result:
					return False
		for slave_lip in slave_lips:
			if slave_lip in config.node_lips:
				result = detect_slave_lip(slave_lip)
				if not result:
					return False
		return True
