# -*- coding: UTF-8 -*-
import gevent
import os
import time
import socket
import json
import random
import shutil

import dns.resolver

from .logger import log
from .config import get_config
from .base import VirtualServerFactory

from shopee_deploy.utils import write_file

class HealthChecker(object):
    OUTPUT_FILE = '/tmp/dpvs_health_check.json'

    def __init__(self):
        self.config = get_config()
        self._last_rets = {}
        self._check_result = ''

    def tcp_check(self, ip, port):
        try:
            socket.create_connection((ip, port), timeout=self.config.tcp_timeout)
            return True
        except:
            return False

    def dns_check(self, ip, port):
        resolver = dns.resolver.Resolver()
        resolver.nameservers = [ip]
        resolver.port = port
        resolver.timeout = self.config.udp_timeout
        resolver.lifetime = self.config.udp_timeout

        try:
            resolver.query('localhost', 'A')
        except dns.exception.Timeout:
            # Only consider dns is unhealthy when timeout.
            return False
        except:
            return True

        return True

    def ping_check(self, ip):
        if os.system("timeout %s ping -c 1 %s" % (self.config.udp_timeout, ip)) == 0:
            return True
        else:
            log.error('ping_check rs ip:%s failed', ip)
            return False

    def check(self, protocol, ip, port, rets):
        ret = False
        if protocol == 'tcp':
            ret = self.tcp_check(ip, port)
        elif protocol == 'udp':
            ret = self.ping_check(ip)

        last_ret = self._last_rets.get((protocol, ip, port))
        if not ret and ret != last_ret:
            log.error('check_result|protocol=%s,ip=%s,port=%s,ret=%s', protocol, ip, port, ret)

        rets[(protocol, ip, port)] = ret
        self._last_rets[(protocol, ip, port)] = ret

    def _run(self):
        check_greenlets = []

        rets = {}

        # Collect all possible protocol, ip and port.
        virtual_servers = VirtualServerFactory.load()
        for vs in virtual_servers:
            if vs.is_deleted:
                continue
            for rs in vs.real_servers:
                rets[(vs.protocol, rs.ip, rs.port)] = None

        # Perform health check.
        for (protocol, ip, port) in rets.keys():
            check_greenlets.append(gevent.spawn(self.check, protocol, ip, port, rets))

        gevent.joinall(check_greenlets)

        # Process result.
        for vs in virtual_servers:
            if vs.is_deleted:
                continue
            is_all_failed = True
            for rs in vs.real_servers:
                ret = rets[(vs.protocol, rs.ip, rs.port)]
                if ret:
                    rs.success()
                else:
                    rs.fail()

                if rs.origin_weight > 0:
                    if rs.effective_weight > 0:
                        is_all_failed = False

            if is_all_failed:
                # When all real servers failed, enable them temporary to return connection refuse or error.
                # Otherwise, client side would hang due to don't have any real server would serve incoming requests.
                for rs in vs.real_servers:
                    if rs.origin_weight > 0:  # ignore rs which origin_weight is 0
                        rs.enable_temporary()

        check_result = json.dumps([vs.to_dict() for vs in virtual_servers if vs.is_deleted is False], indent=2)
        if check_result != self._check_result:
            self._check_result = check_result
            self.update_check_result_file()

    def run(self):
        while True:
            try:
                self._run()
            except BaseException as e:
                log.error('got execption when health checking %s' % e)

            time.sleep(self.config.check_interval)

    def update_check_result_file(self):
        temp_file = '/tmp/dpvs_health_check_%d%d' % (int(time.time()), random.randint(100000, 999999),)
        write_file(temp_file, self._check_result)
        shutil.move(temp_file, self.OUTPUT_FILE)

    @classmethod
    def start(cls):
        instance = cls()
        gevent.spawn(instance.run)
