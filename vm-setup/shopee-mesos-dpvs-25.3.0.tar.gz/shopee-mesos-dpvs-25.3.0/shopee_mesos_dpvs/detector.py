# -*- coding: UTF-8 -*-
import json
import os
import shutil
import time
import random
import re

import gevent
import datetime
from shopee_deploy.utils import execute, write_file, read_file

from .logger import log
from .config import FullnatConfig, get_config
from .config import load_node_config
from .bird import Bird
from .base import IPVSAdminHelper, NATMode, PalShellHelper
from .command import get_command_output_with_lock, GenericFunction
import traceback


class DetectResult(object):
	DETECT_RESULT_INIT_FILE = '/etc/mesos-dpvs/detect_result.json'

	def __init__(self):
		self.bird = BirdDetectResult()
		self.node = NodeDetectResult()
		self._result = ''

	def to_dict(self):
		return {
			'bird': self.bird.to_dict(),
			'node': self.node.to_dict(),
		}

	def update_detect_result_file(self):
		temp_file = '/etc/mesos-dpvs/detect_result_%d%d' % (int(time.time()), random.randint(100000, 999999),)
		write_file(temp_file, self._result)
		shutil.move(temp_file, self.DETECT_RESULT_INIT_FILE)


class BirdDetectResult:
	def __init__(self):
		self.start_success_count = 0  # 截止当前时刻成功start bird的次数
		self.start_failed_count = 0   # 截止当前时刻start bird 失败的次数
		self.stop_success_count = 0   # 截止当前时刻成功stop bird的次数
		self.stop_failed_count = 0    # 截止当前时刻stop bird失败的次数

	def to_dict(self):
		return {
			'start_success_count': self.start_success_count,
			'start_failed_count': self.start_failed_count,
			'stop_success_count': self.stop_success_count,
			'stop_failed_count': self.stop_failed_count
		}


class NodeDetectResult:
	def __init__(self):
		self.success_count = 0  # 截止当前时刻探测成功次数
		self.failed_count = 0   # 截止当前时刻探测失败次数
		self.status = 0         # 实时探测结果: 1:up;0:down

	def to_dict(self):
		return {
			'success_count': self.success_count,
			'failed_count': self.failed_count,
			'status': self.status
		}

class DetectResultMap:
	ENV_INFO_FILE_PATH = '/etc/mesos-dpvs/env_info.json'
	IS_BOND_NIC = False
	def __init__(self):
		self.detect_result_map = {}
		self.last_lan_bytes = 0
		self.last_wan_bytes = 0
		self.last_time = 0

		content = read_file(self.ENV_INFO_FILE_PATH)
		if content:
			config = json.loads(content)
			env_type = config['env_type']
			if env_type == "bond":
				self.IS_BOND_NIC = True

	def __getitem__(self, item):
		return getattr(self, item)

	def datetime_now(self):
		# total_seconds will be in decimals (millisecond precision) GMT+8
		return int((datetime.datetime.now() - datetime.datetime.utcfromtimestamp(8*3600)).total_seconds())

	def get_nic_status(self, lan_nic, wan_nic):
		split_str = ': dpdk'
		device_str = 'dpdk%s'
		if self.IS_BOND_NIC:
			split_str = ': bond'
			device_str = 'bond%s'

		try:
			output = get_command_output_with_lock('dpip link show', exit_on_fail=False).split(split_str)
		except:
			log.exception('run_dpip_link_show_failed')
			return

		# Match
		# 1: dpdk0: socket 0 mtu 1500 rx-queue 16 tx-queue 16
		#     UP 10000 Mbps full-duplex auto-nego foward2kni
		#     addr 52:54:00:34:85:28 OF_RX_IP_CSUM OF_TX_IP_CSUM OF_TX_TCP_CSUM OF_TX_UDP_CSUM
		# 2: dpdk1: socket 1 mtu 1500 rx-queue 16 tx-queue 16
    #     DOWN 0 Mbps full-duplex auto-nego
    #     addr 08:C0:EB:22:3E:BB OF_RX_IP_CSUM OF_TX_IP_CSUM OF_TX_TCP_CSUM OF_TX_UDP_CSUM

		linkstatus_pattern = re.compile(
			r'(?P<nic_id>[\d.]+):\s+.+\n+'
			r'\s+(?P<link_status>[\w.]+)\s+.*'
			)
		nic_bandwidth_pattern = re.compile(
			r'(?P<nic_id>[\d.]+):\s+.+\n+'
			r'\s+(?P<link_status>[\w.]+)\s+(?P<nic_bandwidth>[\d.]+)\s+.*'
			)

		lan_link_status = ""
		wan_link_status = ""
		lan_nic_bandwidth = 0
		wan_nic_bandwidth = 0
		for line in output:
			match = linkstatus_pattern.match(line)
			nic_match = nic_bandwidth_pattern.match(line)
			if match:
				device = device_str % match.group('nic_id')
				if device == lan_nic:
					lan_link_status = match.group('link_status')
					if nic_match:
						lan_nic_bandwidth = int(nic_match.group('nic_bandwidth'))
				if device == wan_nic:
					wan_link_status = match.group('link_status')
					if nic_match:
						wan_nic_bandwidth = int(nic_match.group('nic_bandwidth'))
		return lan_link_status, wan_link_status, lan_nic_bandwidth, wan_nic_bandwidth

	def get_realtime_bandwidth(self, lan_nic, wan_nic):
		split_str = ': dpdk'
		device_str = 'dpdk%s'
		if self.IS_BOND_NIC:
			split_str = ': bond'
			device_str = 'bond%s'

		try:
			output = get_command_output_with_lock('dpip -s link show', exit_on_fail=False).split(split_str)
		except Exception as e:
			log.exception('run_dpip_s_link_show_failed')
			return

			# Match
			# dpdk1.1000: socket 0 mtu 1500 rx-queue 8 tx-queue 8
        #     UP 10000 Mbps full-duplex auto-nego
        #     addr B4:96:91:31:BF:66 OF_RX_IP_CSUM
        #     ipackets            opackets            ibytes              obytes
        #     1904272369          1197515708          381468573412        79280404105
        #     ierrors             oerrors             imissed             rx_nombuf
        #     0                   0                   0                   0
        #     mbuf-avail          mbuf-inuse
        #     2064760             32391

		nic_stats_pattern = re.compile(
			r'(?P<nic_id>[\d.]+):\s+.+\n+.+\n.+\n.+\s+'
			r'obytes\s+'
			r'(?P<receive_packets>\d+)\s+'
			r'(?P<transmit_packets>\d+)\s+'
			r'(?P<receive_bytes>\d+)\s+'
			r'(?P<transmit_bytes>\d+)\s+'
			r'.*\s+'
			r'(?P<receive_errors>\d+)\s+'
			r'(?P<transmit_errors>\d+)\s+'
			r'(?P<receive_missed>\d+)\s+'
			r'(?P<receive_nombuf>\d+)\s+'
			r'.*\s+'
			r'(?P<mbuf_avail_bytes>\d+)\s+'
			r'(?P<mbuf_inuse_bytes>\d+)'
    )
		lan_receive_bytes = 0
		wan_receive_bytes = 0
		for line in output:
			match = nic_stats_pattern.match(line)
			if match:
				device = device_str % match.group('nic_id')
				if device == lan_nic:
					lan_receive_bytes = int(match.group('receive_bytes'))
				if device == wan_nic:
					wan_receive_bytes = int(match.group('receive_bytes'))

		return lan_receive_bytes, wan_receive_bytes

	def store_detect_result(self, result, lan_nic, wan_nic):
		time_now = self.datetime_now()

		now_lan_bytes, now_wan_bytes = self.get_realtime_bandwidth(lan_nic, wan_nic)
		max_bandwidth = max(now_lan_bytes - self.last_lan_bytes, now_wan_bytes - self.last_wan_bytes)
		realtime_bandwidth = '%.2f' % (max_bandwidth/float(time_now-self.last_time if time_now-self.last_time > 0 else 1))

		self.last_lan_bytes = now_lan_bytes
		self.last_wan_bytes = now_wan_bytes
		self.last_time = time_now

		lan_link_status, wan_link_status, lan_nic_bandwidth, wan_nic_bandwidth = self.get_nic_status(lan_nic, wan_nic)

		nic_bandwidth = lan_nic_bandwidth
		if wan_nic_bandwidth != 0 and wan_nic_bandwidth < lan_nic_bandwidth:
			nic_bandwidth = wan_nic_bandwidth

		self.detect_result_map[time_now] = {
			"detect_result": result,
			"lan_bgp_status": True if 'Established' in get_command_output_with_lock('birdcl show protocol all|grep lan_bgp||echo "Not running"', exit_on_fail=False) else False,
			"wan_bgp_status": True if 'Established' in get_command_output_with_lock('birdcl show protocol all|grep wan_bgp||echo "Not running"', exit_on_fail=False) else False,
			"lan_link_status": lan_link_status.encode('utf-8'),
			"wan_link_status": wan_link_status.encode('utf-8'),
			"bird_service_status": GenericFunction.is_service_active('bird.service'),
			"realtime_bandwidth": float(realtime_bandwidth),
			"nic_bandwidth": float(nic_bandwidth/1000),
			"time": time_now,
		}

	def get_detect_result(self):
		ten_min = 600
		time_to_expire = self.datetime_now() - ten_min

		map = {}
		for k,v in self.detect_result_map.items():
			if k > time_to_expire:
				map[k] = v
		self.detect_result_map=map

		# will sort in node-controller
		return json.dumps(list(map.values()))

class Detector(object):
	detector_result = DetectResultMap()
	DPVS_UPGRADING_FILE = '/var/run/dpvs_upgrading'
	DPVS_CONF_INIT_FILE = '/var/run/dpvs_fullnat_conf_init'
	last_call_time = 0
	dpvs_down = False
	critical_check_fail = False
	def __init__(self, config, nat_mode):
		self.config = config
		self.nat_mode = nat_mode

		self._last_ret = None
		self.success_count = 0
		self.fail_count = 0

		self.config = get_config()

		# skip if node is fullnat mode with single(lan) nic
		if self.nat_mode == NATMode.SNAT:
			self.add_ip_route()

		self.detect_result = DetectResult()
		
		with open('/proc/sys/kernel/core_pattern', 'r') as file:
			content = file.read()
			index = content.rfind('/')
			if index != -1:
				self.CORE_DUMP_PATH = content[:index]
				log.info('core dump path: %s' % self.CORE_DUMP_PATH)
			else:
				log.error('get core dump path failed: %s' % content)

	def add_ip_route(self):
		cmd = 'ip ro add %s via %s' % (self.config.wan_switch_ip,self.config.lan_inner_ip)
		try:
			# new we can use kernel ping wan switch to check connection between switch and dpvs node.
			execute(cmd)
		except SystemExit as e:
			if e.code == -1:
				log.info('ip route existing: %s, exception: %s' % (cmd, e))
			else:
				raise e

	def success(self):
		self.success_count += 1
		self.fail_count = 0
		if self.success_count > self.config.start_status_change_limit and not Bird.is_running() and "READY" == self.config.node_status:
			if os.path.exists(self.DPVS_UPGRADING_FILE):
				log.info('DPVS_UPGRADING_FILE %s exist, will not start Bird' % self.DPVS_UPGRADING_FILE )
				return
			if not self.ensure_dpvs_has_session():
				log.error('dpvs has no sync session record')
				return
			try:
				if FullnatConfig.IS_STANDARD_CLUSTER:
					bird_start_func = Bird.multi_stage_advertise
				else:
					bird_start_func = Bird.start
				if bird_start_func():
					self.detect_result.bird.start_success_count += 1
					log.info('lan_nic_marked_success|ip=%s', self.config.lan_inner_ip)
				else:
					self.detect_result.bird.start_failed_count += 1

			except BaseException as e:
				self.detect_result.bird.start_failed_count += 1
				log.error('got exception when start bird %s' % e)

	def fail(self):
		self.fail_count += 1
		if self.fail_count > self.config.status_change_limit:
			operate_bird_flag = self.check_and_stop_bird()
			if operate_bird_flag:
				log.info('lan_nic_marked_fail|ip=%s', self.config.lan_inner_ip)
		self.success_count = 0

	def check_and_stop_bird(self):
		if Bird.is_running():
			try:
				if Bird.stop_with_lock():
					self.detect_result.bird.stop_success_count += 1
					return True
				else:
					self.detect_result.bird.stop_failed_count += 1
			except BaseException as e:
				self.detect_result.bird.stop_failed_count += 1
				log.error('got exception when stop bird %s' % e)
		return False

	def ping(self, ip, timeout):
		# don't know why, but when timeout in cmd or params is missing, timeout doesn't work
		if execute("timeout %s ping -c 1 %s" % (timeout, ip), exit_on_fail=False, timeout=timeout):
			return True
		else:
			log.error('ping_check ip:%s failed', ip)
			return False

	def detect_node_health(self):
		ret = self.ping(self.config.lan_inner_ip, 0.5)
		if not ret and self._last_ret != ret:
			log.error('detect_result|ret=%s', ret)
		self._last_ret = ret
		if not ret:
			log.error('ping lan_inner_ip %s failed' % self.config.lan_inner_ip)
			return False
		if self.nat_mode == NATMode.SNAT:
			snat_vs = IPVSAdminHelper.get_snat_servers()
			if snat_vs is None:
				log.error('can not get snat_vs list')
			elif len(snat_vs) == 0:
				log.error('snat virtual servers list is empty or cannot get')
				return False

			if not self.ping(self.config.wan_switch_ip, 0.5):
				log.error('ping wan_switch_ip %s failed' % self.config.wan_switch_ip)
				return False
		elif self.nat_mode == NATMode.FULLNAT:
			if os.path.exists(self.DPVS_CONF_INIT_FILE):
				log.info('dpvs init config not done')
				return False
		else:
			log.error('nat mode error! exit shopee-mesos-dpvs')
			exit(-1)

		return True

	def _run(self):
		try:
			result = "Init"
			outof_control_time = self.detector_result.datetime_now() - self.last_call_time
			if outof_control_time > 300: # 启用离线模式
				if "NOTREADY" == self.config.node_status:
					operate_bird_flag = self.check_and_stop_bird()
					if operate_bird_flag:
						log.info('node_status is NOTREADY, bird has been stopped')
			
			self.dpvs_down = False
			# systemctl is-active 依旧需要，为了防止dpvs正常退出（没有coredump）+lan inner ip被错误的配置到其他节点上
			if not GenericFunction.is_service_active('dpvs'):
				log.error('dpvs is inactive')
				self.dpvs_down = True
			if not self.critical_check_fail and not self.dpvs_down and self.detect_node_health():
				self.detect_result.node.success_count += 1
				self.detect_result.node.status = 1
				result = "Success"
				if outof_control_time > 300: # 启用离线模式
					self.success()
			else:
				self.detect_result.node.failed_count += 1
				self.detect_result.node.status = 0
				result = "Fail"
				if outof_control_time > 300: # 启用离线模式
					self.fail()
			if self.dpvs_down:
				result = "DPVSDown"
			self.detector_result.store_detect_result(result, self.config.lan_nic, self.config.wan_nic)
		except BaseException as e:
			log.error('alert: got exception: %s when detecting node %s' % (e, traceback.format_exc()))

	def run(self):
		while True:
			load_node_config()
			self._run()
			# 探测结果落文件
			self.detect_result._result = json.dumps(self.detect_result.to_dict(), indent=2)
			self.detect_result.update_detect_result_file()

			time.sleep(self.config.check_interval)
	
	def critical_check(self):
		load_node_config()
		while True:
			try:
				self.critical_check_fail = False
				if not Bird.is_running():
					# bird is not running, skip critical check to avoid unnecessary log
					time.sleep(self.config.critical_check_interval)
					continue
				if len(self.config.core_dump_file_path) == 0:
					log.error('alert: core dump path prefix is empty, skip critical check')
					time.sleep(self.config.critical_check_interval)
					continue
				if not execute('pal-shell version', exit_on_fail=False, timeout = self.config.critical_check_timeout):
					log.error('pal-shell version failed, dpvs may down')
					if not self.ping(self.config.lan_inner_ip, self.config.critical_check_timeout):
						log.error('ping lan_inner_ip %s failed, dpvs may down' % self.config.lan_inner_ip)
						for name in self.config.dpvs_thread_names:
							file_name = get_command_output_with_lock('find %s -type f -mmin -1 -name "%s%s%s*"' % (self.CORE_DUMP_PATH, self.config.core_dump_file_prefix, name, self.config.core_dump_file_suffix), exit_on_fail=False)
							if len(file_name.strip()) > 0:
								log.error('alert: find core dump file: %s, dpvs was crushed, stop bird' % file_name)
								self.check_and_stop_bird()
								self.critical_check_fail = True
								break
				time.sleep(self.config.critical_check_interval)
			except BaseException as e:
				log.error('alert: got exception: %s when critical check, stacktrace: %s' % (e, traceback.format_exc()))
				time.sleep(self.config.critical_check_interval)

	@classmethod
	def start(cls, config, nat_mode):
		instance = cls(config, nat_mode)
		gevent.spawn(instance.critical_check)
		gevent.spawn(instance.run)

	@classmethod
	def ensure_dpvs_has_session(cls):
		# 目前通过检测：
		# 	1.dpvs启动后是否进行过全量会话同步
		# 判断dpvs是否具有完整的会话信息，如果没有的话就发起一次全量会话同步
		if not FullnatConfig.IS_STANDARD_CLUSTER:
			log.info('no sync session for non std')
			return True
		sync_config = PalShellHelper.load_sync_session()
		if len(sync_config.sync_session_dst_ips) == 0 and len(sync_config.sync_session_dpdk_dst_ips) == 0:
			log.info('no sync session for the only node in cluster')
			return True
		if cls.has_session_sync_record():
			return True

		log.error('has no session sync log, start session sync')

		try:
			session_sync_service = "dpvs-conn-sync-once.service"
			if not GenericFunction.is_service_activating(session_sync_service):
				# TODO: 这里同步有问题可能触发超时，execute函数超时没有任何日志，只会发exit(-1)
				execute('systemctl start %s' % session_sync_service, timeout=60)

			# 认为现网的会话规模，60秒足够完成同步
			for _ in range(12):
				time.sleep(5)
				if GenericFunction.is_service_activating(session_sync_service):
					continue
				elif cls.has_session_sync_record():
					log.info('dpvs has sync record after sync session')
					return True
				else:
					log.error('alert: dpvs has no record after sync session')
					return False
			log.error('alert: sync session timeout')
			return False
		except BaseException as e:
			log.error('alert: sync session failed: %s' % e)
			return False


	@classmethod
	def has_session_sync_record(cls):
		try:
			execute("journalctl -u dpvs.service --since \"$(systemctl show -p ActiveEnterTimestamp dpvs.service | awk '{print $2 $3}')\" | grep -q \"recv sync all ctl pkt: sync all finish\"")
			return True
		except:
			return False
