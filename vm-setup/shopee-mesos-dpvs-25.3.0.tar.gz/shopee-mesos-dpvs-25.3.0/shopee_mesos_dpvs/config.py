# -*- coding: UTF-8 -*-
import json
from .logger import log
from shopee_deploy.utils import read_file
from .config_center import module_config
import os

class DPVSConfig(object):

	def __init__(self):
		self.status_change_limit = None
		self.start_status_change_limit = 10
		self.ctrl_poll_interval = None

	def config_path(self):
		raise NotImplementedError()

	def load(self):
		content = read_file(self.config_path())
		if not content:
			log.error('%s does not exist or empty' % self.config_path())
			exit(-1)
		config = json.loads(content)
		self.__dict__.update(config)


class SnatConfig(DPVSConfig):

	def __init__(self):
		super(self.__class__, self).__init__()

		self.wan_ips = []

		self.wan_mask = None
		self.wan_switch_ip = None
		self.wan_nic = None

		self.lan_inner_ip = None
		self.lan_mask = None
		self.lan_switch_ip = None
		self.lan_switch_as = None
		self.lan_nic = None
		self.check_interval = 0.5

		self.custom_routes = []

		self.is_bird_enabled = True

		self.src_range = '10.0.0.0-10.255.255.255'

		self.load()

	def config_path(self):
		return '/etc/mesos-dpvs/snat.json'


class FullnatConfig(DPVSConfig):
	NODE_LIP_CHANGED = False
	IS_STANDARD_CLUSTER = False
	DEFAULT_LOCAL_AS = 65000
	HAS_WAN_NIC = True

	def __init__(self):
		super(self.__class__, self).__init__()

		self.wan_vips = []
		self.wan_inner_ip = None
		self.wan_mask = None
		self.wan_switch_ip = None
		self.wan_switch_as = None
		self.wan_local_as = self.DEFAULT_LOCAL_AS
		self.wan_nic = None

		self.lan_vips = []
		self.lan_inner_ip = None
		self.lan_mask = None
		self.lan_switch_ip = None
		self.lan_switch_as = None
		self.lan_local_as = self.DEFAULT_LOCAL_AS
		self.lan_nic = None

		self.check_interval = None
		self.tcp_timeout = None
		self.udp_timeout = None

		self.cluster_uuid = ""

		# configs of new cluster(standard cluster)
		self.cluster_type = None
		self.use_dpdk_sync_session = 0
		self.sync_session_src_ip = None
		self.sync_session_dst_ips = []
		self.sync_session_port = 0
		self.sync_session_dpdk_src_ip = None
		self.sync_session_dpdk_dst_ips = []

		self.node_lips = []
		self.master_node_lips = []
		self.NODE_LIP_CHANGED = False

		# standard cluster default
		self.realtime_send = 1
		self.realtime_recv = 1
		# dpvs will discard it so we don't match
		self.dpdk_sync_session_src_mac = None
		self.enable_qos_drop = False
		self.node_status = "READY"

		self.vips = set()
		self.master_lips = set()   # master_node_lip + master_outer_lip
		self.lips = set()          # node_lip + outer_lip

		self.bgp_keepalive_time = 10
		self.bgp_hold_time = 30
		self.critical_check_interval = 0.5
		self.critical_check_timeout = 0.5
		self.dpvs_thread_names = []
		self.wan_bfd = False
		self.bfd_multiplier = 3
		self.bfd_min_rx_interval = 100
		self.bfd_min_tx_interval = 100


		self.load()
		if self.cluster_type in ('standard-4', 'standard-8'):
			FullnatConfig.IS_STANDARD_CLUSTER = True

		BOND_KEYWORD = 'bond'
		if not self.wan_nic:
			FullnatConfig.HAS_WAN_NIC = False
		# 临时的命名规范：如果lan nic以bond开头而wan nic不以bond开头，视为lan集群
		elif not self.wan_nic.startswith(BOND_KEYWORD) and self.lan_nic.startswith(BOND_KEYWORD):
			FullnatConfig.HAS_WAN_NIC = False

		_config = module_config.get_from_local_config("bgp_config", {
			"bgp_keepalive_time": self.bgp_keepalive_time,
			"bgp_hold_time": self.bgp_hold_time,
			"wan_bfd": self.wan_bfd,
			"bfd_multiplier": self.bfd_multiplier,
			"bfd_min_rx_interval": self.bfd_min_rx_interval,
			"bfd_min_tx_interval": self.bfd_min_tx_interval,
		})
		self.bgp_keepalive_time = _config["bgp_keepalive_time"]
		self.bgp_hold_time = _config["bgp_hold_time"]
		self.wan_bfd = _config.get("wan_bfd", self.wan_bfd)
		self.bfd_multiplier = _config.get("bfd_multiplier", self.bfd_multiplier)
		self.bfd_min_rx_interval = _config.get("bfd_min_rx_interval", self.bfd_min_rx_interval)
		self.bfd_min_tx_interval = _config.get("bfd_min_tx_interval", self.bfd_min_tx_interval)

	def get_vips(self):
		vips = list(self.vips)
		vips.sort()
		return vips

	def set_vips(self, vips):
		self.vips = vips

	def get_master_lips(self):
		master_lips = list(self.master_lips)
		master_lips.sort()
		return master_lips

	def set_master_lips(self, master_lips):
		self.master_lips = master_lips

	def get_lips(self):
		lips = list(self.lips)
		lips.sort()
		return lips

	def set_lips(self, lips):
		self.lips = lips

	def config_path(self):
		return '/etc/mesos-dpvs/fullnat.json'


_config = None


def get_config():
	global _config

	return _config


def load_config(mode):
	global _config

	if mode == 'fullnat':
		_config = FullnatConfig()
	elif mode == 'snat':
		_config = SnatConfig()

# only used for fullnat mode
# TODO: validate config value before update
def load_node_config():
	global _config
	if _config is None:
		log.error('global _config is None')
		exit(-1)

	update_bgp_config(_config)
	content = read_file(_config.config_path())
	if not content:
		log.error('%s does not exist or empty' % _config.config_path())
		return
	config = json.loads(content)
	log.info('load_node_config from %s' % _config.config_path())

	if set(_config.node_lips) != set(config.get("node_lips")):
		_config.NODE_LIP_CHANGED = True
		_config.node_lips = config.get("node_lips")
	if set(_config.master_node_lips) != set(config.get("master_node_lips")):
		_config.NODE_LIP_CHANGED = True
		_config.master_node_lips = config.get("master_node_lips")
	if _config.NODE_LIP_CHANGED:
		log.info('node_lip_has_changed')
	_config.enable_qos_drop = config.get("enable_qos_drop", False)
	_config.node_status = config.get("node_status", "READY")

	_config.wan_switch_ip = config.get("wan_switch_ip")
	_config.wan_switch_as = config.get("wan_switch_as")
	_config.wan_local_as = config.get("wan_local_as", FullnatConfig.DEFAULT_LOCAL_AS)
	_config.wan_inner_ip = config.get("wan_inner_ip")
	_config.wan_mask = config.get("wan_mask")

	_config.lan_switch_ip = config.get("lan_switch_ip")
	_config.lan_switch_as = config.get("lan_switch_as")

	_config.lan_local_as = config.get("lan_local_as", FullnatConfig.DEFAULT_LOCAL_AS)
	_config.lan_inner_ip = config.get("lan_inner_ip")
	_config.lan_mask = config.get("lan_mask")

	_config.status_change_limit = config.get("status_change_limit", 3)
	_config.ctrl_poll_interval = config.get("ctrl_poll_interval", 5)
	_config.check_interval = config.get("check_interval", 5)
	_config.tcp_timeout = config.get("tcp_timeout", 3)
	_config.udp_timeout = config.get("udp_timeout", 0.5)
	_config.critical_check_interval, _ = module_config.get_precise("critical_check_interval", _config.critical_check_interval)
	_config.critical_check_timeout, _ = module_config.get_precise("critical_check_timeout", _config.critical_check_timeout)
	_config.dpvs_thread_names, _ = module_config.get_precise("dpvs_thread_names", _config.dpvs_thread_names)

	with open('/proc/sys/kernel/core_pattern', 'r') as file:
		core_pattern = file.read()
		# 获取目录部分
		directory = os.path.dirname(core_pattern)
		# 提取文件名部分
		filename_with_placeholders = os.path.basename(core_pattern)
		# 分离前缀和后缀
		if '%e' in filename_with_placeholders:
			_config.core_dump_file_path = directory
			_config.core_dump_file_prefix = filename_with_placeholders.split('%e')[0]  # 文件名前缀
			_config.core_dump_file_suffix = filename_with_placeholders.split('%e')[1].split('%')[0]  # %e 后面到下一个 % 之前的部分

	return


def reset_node_config_change_flags():
	global _config
	_config.NODE_LIP_CHANGED = False

def update_bgp_config(config):
	# TODO: config封装to_dict方法
	_config, _ = module_config.get_precise("bgp_config", {
		"bgp_keepalive_time": config.bgp_keepalive_time,
		"bgp_hold_time": config.bgp_hold_time,
		"wan_bfd": config.wan_bfd,
		"bfd_multiplier": config.bfd_multiplier,
		"bfd_min_rx_interval": config.bfd_min_rx_interval,
		"bfd_min_tx_interval": config.bfd_min_tx_interval,
	})
	config.bgp_keepalive_time = _config["bgp_keepalive_time"]
	config.bgp_hold_time = _config["bgp_hold_time"]
	config.wan_bfd = _config.get("wan_bfd", config.wan_bfd)
	config.bfd_multiplier = _config.get("bfd_multiplier", config.bfd_multiplier)
	config.bfd_min_rx_interval = _config.get("bfd_min_rx_interval", config.bfd_min_rx_interval)
	config.bfd_min_tx_interval = _config.get("bfd_min_tx_interval", config.bfd_min_tx_interval)