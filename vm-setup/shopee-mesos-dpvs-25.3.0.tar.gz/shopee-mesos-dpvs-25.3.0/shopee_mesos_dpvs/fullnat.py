# -*- coding: UTF-8 -*-
import json
import os
import signal
import re
import traceback

import socketserver
from shopee_deploy.utils import execute, generate_content_by_template

from shopee_mesos_dpvs import command

from .config import load_node_config, load_config, get_config, FullnatConfig
from .detector import Detector
from .bird import Bird

from .base import cli, DPVS, DPIPHelper, Route, IPWithMask, IPHelper, IPVSAdminHelper, PalShellHelper, \
	VirtualServerFactory, SnatServerFactory, NATMode, GetMesosHCMod
from .command import GenericFunction
from .health_checker import HealthChecker
from .logger import log
from SocketServer import ThreadingMixIn
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import gevent
from .config_center import module_config
from packaging.version import Version

MESOS_API_SOCKET_PATH = '/var/run/mesos_api.socket'


class FullnatDPVS(DPVS):

	DPVS_CONF_INIT_FILE = '/var/run/dpvs_fullnat_conf_init'
	SYNC_DPDK_MODE_PATH = '/etc/mesos-dpvs/sync_dpdk_mode'
	LOAD_LIST_INTERVAL = 3 # 对账前载入当前配置（而不用内存缓存）的次数间隔
	load_list_counter = 0

	def __init__(self):
		super(self.__class__, self).__init__()
		self.config = get_config()
		self._nics = []
		self._existing_virtual_servers = None
		self.pre_master_mod = module_config.get_from_local_config("health_check_mod", {}).get("master_mod", "non-inbound")
		log.info("Init pre_master_mod to %s", self.pre_master_mod)
		# 获取shopee-mesos-dpvs health mod
		GetMesosHCMod.get_mod()

		if GetMesosHCMod.IS_MESOS_WITH_HC:
			HealthChecker.start()

		Detector.start(self.config, NATMode.FULLNAT)

	def get_health_check_mod(self):
		check_mod, _ = module_config.get_precise("health_check_mod", {})
		master_mod = check_mod.get("master_mod", self.pre_master_mod)
		if master_mod != self.pre_master_mod:
			log.info("Change master_mod to %s", master_mod)
			self.pre_master_mod = master_mod
		return master_mod

	def init_rs_weight(self, virtual_servers, existing_virtual_servers):
		if existing_virtual_servers:
			init_info = {}
			for vs in existing_virtual_servers:
				for rs in vs.real_servers:
					init_info[vs.vip, vs.port, vs.protocol, rs.ip, rs.port, rs.vni] = rs

			for vs in virtual_servers:
				if vs.is_deleted:
					continue
				for rs in vs.real_servers:
					key = (vs.vip, vs.port, vs.protocol, rs.ip, rs.port, rs.vni)
					if init_info.has_key(key):
						init_rs = init_info.get(key)
						# modify effective and origin weight
						if rs.origin_weight > 0:
							rs.change_weight(init_rs.effective_weight)

	def process_health_check(self, request):
		update_weight_map = {}
		for vs in request['services']:
			for rs in vs['real_servers']:
				key = (vs['vip'], vs['port'], vs['protocol'], rs['ip'], rs['port'], str(rs['vni']))
				update_weight_map[key] = rs
		for vs in VirtualServerFactory.load():
			if vs.is_deleted:
				continue
			is_all_dead = True
			vs_changed_rs = {}
			with vs.lock:
				for rs in vs.real_servers:
					key = (vs.vip, vs.port, vs.protocol, rs.ip, rs.port, rs.vni)
					if update_weight_map.has_key(key) and rs.origin_weight > 0:
						# modify weight of rs
						update_rs_dict = update_weight_map[key]
						if rs.up != update_rs_dict['up']:
							if update_rs_dict['up']:
								rs.change_weight(rs.origin_weight)
							else:
								rs.change_weight(0)
							rs.change_health_status(update_rs_dict['up'])
							vs_changed_rs[key] = rs
							log.info("changed rs is %s" % rs.to_dict())
					if rs.origin_weight > 0 and rs.up:
						is_all_dead = False

				if len(vs_changed_rs) > 0:
					for rs in vs.real_servers:
						key = (vs.vip, vs.port, vs.protocol, rs.ip, rs.port, rs.vni)
						if is_all_dead:
							# ignore rs which origin_weight is 0
							if rs.origin_weight > 0:
								rs.enable_temporary()
								# Configure the rs weight of all dead
								IPVSAdminHelper.set_rs_weight(vs, rs)
						else:
							if vs_changed_rs.has_key(key):
								IPVSAdminHelper.set_rs_weight(vs, rs)
							elif not rs.up and rs.origin_weight > 0:
								rs.change_weight(0)
								IPVSAdminHelper.set_rs_weight(vs, rs)

	def reset(self):
		self._nics = []
		self._existing_virtual_servers = None
		VirtualServerFactory.EXISTING_LIPS = set()
		PalShellHelper.ENABLE_QOS_UPDATE = True
		DPVS.dpvs_version = Version('0') # default minimum version

	def config_wan_vlan(self, nics):
		if FullnatConfig.HAS_WAN_NIC and len(self.config.wan_nic.split('.')) > 1:
			wan_origin_nic, wan_vlan_id = self.config.wan_nic.split('.')
			DPIPHelper.add_vlan(wan_origin_nic, wan_vlan_id, nics=nics)

	def config_lan_vlan(self, nics):
		if len(self.config.lan_nic.split('.')) > 1:
			lan_origin_nic, lan_vlan_id = self.config.lan_nic.split('.')
			DPIPHelper.add_vlan(lan_origin_nic, lan_vlan_id, nics=nics)

	def update_non_standard_cluster_bird_config(self):
		bird_template_file = os.path.join(os.path.dirname(__file__), 'res', 'bird_fullnat.conf.j2')
		content_map = {
			"wan_inner_ip": self.config.wan_inner_ip,
			"wan_mask": self.config.wan_mask,
			"wan_switch_ip": self.config.wan_switch_ip,
			"wan_switch_as": self.config.wan_switch_as,
			"wan_local_as": self.config.wan_local_as,
			"has_wan_nic": self.config.HAS_WAN_NIC,
			"vips": self.config.get_vips(),
			"lan_inner_ip": self.config.lan_inner_ip,
			"lan_mask": self.config.lan_mask,
			"lan_switch_ip": self.config.lan_switch_ip,
			"lan_switch_as": self.config.lan_switch_as,
			"lan_local_as": self.config.lan_local_as,
			"lan_nic": self.config.lan_nic,
			"bgp_keepalive_time": self.config.bgp_keepalive_time,
			"bgp_hold_time": self.config.bgp_hold_time,
			"wan_nic": self.config.wan_nic,
			"wan_bfd": self.config.wan_bfd,
			"bfd_multiplier": self.config.bfd_multiplier,
			"bfd_min_rx_interval": self.config.bfd_min_rx_interval,
			"bfd_min_tx_interval": self.config.bfd_min_tx_interval,
			"has_snat": len(SnatServerFactory.load()) > 0,
		}

		content = generate_content_by_template(bird_template_file, **content_map)
		return Bird.update_config(content)

	def sync_virtual_servers(self, nics):
		new_virtual_servers = VirtualServerFactory.load()
		PalShellHelper.batch_add_update_qos(self.config)
		PalShellHelper.enable_various_switch()
		if self._existing_virtual_servers is None:
			# which means update_virtual_servers() is called first time after mesos-dpvs or dpvs started
			self._existing_virtual_servers = IPVSAdminHelper.get_virtual_servers()
			self.init_rs_weight(new_virtual_servers, self._existing_virtual_servers)
		elif FullnatDPVS.load_list_counter >= FullnatDPVS.LOAD_LIST_INTERVAL:
			# 用这种方式来实现ipvsadm删除lip失败，需要持续重试并避免bgp发布的需求
			FullnatDPVS.load_list_counter = 0
			self._existing_virtual_servers = IPVSAdminHelper.get_virtual_servers()
		else:
			FullnatDPVS.load_list_counter += 1

		self._existing_virtual_servers = IPVSAdminHelper.update_virtual_servers(
			new_virtual_servers,
			nics,
			self.config,
			existing_virtual_servers=self._existing_virtual_servers
		)
		# del qos conf after qos unbind vs
		PalShellHelper.batch_del_qos()

	def get_virtual_servers(self):
		return self._existing_virtual_servers

	def sync_session_sync(self):
		sync_status = PalShellHelper.load_sync_session()
		existing_sync_status = PalShellHelper.get_sync_status()

		if sync_status.sync_session_src_ip == '':
			sync_status.sync_session_dpdk_src_ip = '0.0.0.0'
		if sync_status.sync_session_dpdk_src_ip == '':
			sync_status.sync_session_dpdk_src_ip = '0.0.0.0'

		PalShellHelper.update_sync_status(sync_status, existing_sync_status)

		if os.path.exists(self.SYNC_DPDK_MODE_PATH) and existing_sync_status.use_dpdk_sync_session != 1:
			execute('pal-shell sync dpdk_send_mode 1')
		elif not os.path.exists(self.SYNC_DPDK_MODE_PATH) and existing_sync_status.use_dpdk_sync_session != 0:
			execute('pal-shell sync dpdk_send_mode 0')

	def post_up(self):
		fullnat_vs = IPVSAdminHelper.get_virtual_servers()
		if fullnat_vs is None:
			log.error('fail to get fullnat vs list')
		elif len(fullnat_vs) == 0 and not os.path.exists(self.DPVS_CONF_INIT_FILE):
			log.info('dpvs restart, touch %s' % self.DPVS_CONF_INIT_FILE)
			command.touch(self.DPVS_CONF_INIT_FILE)

		nics = DPIPHelper.get_nics()

		self.config_wan_vlan(nics)
		self.config_lan_vlan(nics)

		self._nics = nics
		PalShellHelper.qos_add_del_ignore_list = [
			'conn-sync-send',
			self.config.wan_nic + '-in-bytes',
			self.config.lan_nic + '-in-bytes',
			self.config.wan_nic + '-out-bytes',
			self.config.lan_nic + '-out-bytes',
			]
		if len(self.config.lan_nic.split('.')) > 1:
			lan_origin_nic = self.config.lan_nic.split('.')[0]
			PalShellHelper.qos_add_del_ignore_list.extend([
				lan_origin_nic + '-in-bytes',
				lan_origin_nic + '-out-bytes',
			])
		if len(self.config.wan_nic.split('.')) > 1:
			wan_origin_nic = self.config.wan_nic.split('.')[0]
			PalShellHelper.qos_add_del_ignore_list.extend([
				wan_origin_nic + '-in-bytes',
				wan_origin_nic + '-out-bytes',
			])
		DPVS.dpvs_version = GenericFunction.get_dpvs_version()

	def run(self):
		load_node_config()
		self.reconcile_routes()
		# `sync_virtual_servers` would generate new VIPs and new LIPs.
		self.sync_virtual_servers(self._nics)
		self.reconcile_kni_addrs()
		self.reconcile_addrs()
		# Trigger when VIPs change or when VIPs set up.
		if FullnatConfig.IS_STANDARD_CLUSTER:
			self.sync_session_sync()

		if FullnatConfig.IS_STANDARD_CLUSTER:
			Bird.multi_stage_advertise("reload")      # we control bird start/stop in node_detect task and execute_bird interface
		else:
			if self.update_non_standard_cluster_bird_config():
				if Bird.is_running():
					Bird.reload()
				else:
					pass   # we control bird start/stop in node_detect task and execute_bird interface

		if os.path.exists(self.DPVS_CONF_INIT_FILE):
			log.info('dpvs fullnat config init done, rm %s' % self.DPVS_CONF_INIT_FILE)
			os.remove(self.DPVS_CONF_INIT_FILE)

	def reconcile_routes(self):
		# 在对账路由时不更新nic_map，需要确保除对账本身之外其他地方不会用到nic_map里的路由信息
		def reconcile_route(nic_name, ip, mask, gw_ip):
			exists_route = None
			for route in self._nics[nic_name].routes:
				if ip == route.ip and mask == route.mask:
					exists_route = route
					break
			new_route = Route(ip, mask, gw_ip)
			if not exists_route:
				# init route
				DPIPHelper.add_route(nic_name, new_route, self._nics)
			elif gw_ip != exists_route.gateway:
				log.info('switch ip updated, old ip: %s, new ip: %s' % (exists_route.gateway, new_route.gateway))
				DPIPHelper.del_route(nic_name, exists_route, self._nics)
				DPIPHelper.add_route(nic_name, new_route, self._nics)

		DPIPHelper.get_route(self._nics)
		# 目前只对交换机路由
		reconcile_route(self.config.lan_nic, '10.0.0.0', 8, self.config.lan_switch_ip)
		if FullnatConfig.HAS_WAN_NIC:
			reconcile_route(self.config.wan_nic, '0.0.0.0', 0, self.config.wan_switch_ip)

	def reconcile_addrs(self):
		DPIPHelper.get_addr(self._nics)

		new_addrs = DPIPHelper.new_addr_set
		lan_nic = self.config.lan_nic
		new_lan_addrs = set()
		new_wan_addrs = set()
		exist_lan_addrs = set(self._nics[lan_nic].ip_with_masks)
		exist_wan_addrs = set()
		for addr in new_addrs:
			if IPHelper.is_internal_ip(addr.ip) and addr.ip != self.config.wan_inner_ip:
				new_lan_addrs.add(addr)
			else:
				new_wan_addrs.add(addr)

		for ip in exist_lan_addrs.difference(new_lan_addrs):
			DPIPHelper.del_ip(ip, lan_nic)

		for ip in new_lan_addrs.difference(exist_lan_addrs):
			DPIPHelper.add_ip(lan_nic, ip_with_mask=ip, nics=self._nics)

		if not FullnatConfig.HAS_WAN_NIC:
			return
		wan_nic = self.config.wan_nic
		exist_wan_addrs = set(self._nics[wan_nic].ip_with_masks)
		for ip in exist_wan_addrs.difference(new_wan_addrs):
			DPIPHelper.del_ip(ip, wan_nic)

		for ip in new_wan_addrs.difference(exist_wan_addrs):
			DPIPHelper.add_ip(wan_nic, ip_with_mask=ip, nics=self._nics)
		return

	def reconcile_kni_addrs(self):
		IPHelper.get_nics()
		if FullnatConfig.HAS_WAN_NIC:
			wan_kni = '%s.kni' % (self.config.wan_nic,)
			new_ips = set([IPWithMask(self.config.wan_inner_ip, self.config.wan_mask)])
			exist_ips = set(IPHelper.nics[wan_kni].ip_with_masks)
			for ip_mask in exist_ips.difference(new_ips):
				IPHelper.del_ip(wan_kni, ip_mask)
			for ip_mask in new_ips.difference(exist_ips):
				IPHelper.add_ip(wan_kni, ip_mask)

class UnixSocketHttpServer(socketserver.UnixStreamServer, object):
	def get_request(self):
		request, client_address = super(UnixSocketHttpServer, self).get_request()
		return request, ["local", 0]


def api_run(DPVS):
	class myHandler(BaseHTTPRequestHandler):
		def do_POST(self):
			try:
				if self.path == "/apis/shopee-mesos/v1/rs/update_weight":
					# get request body
					request = self.rfile.read(int(self.headers.getheader('content-length')))
					request_body = json.loads(request)
					if request_body['services']:
						health_check_mod = request_body.get('health_check_mod')
						if health_check_mod is not None:
							if health_check_mod == DPVS.get_health_check_mod():
								gevent.joinall([gevent.spawn(DPVS.process_health_check, request_body)])
						else:
							gevent.joinall([gevent.spawn(DPVS.process_health_check, request_body)])

						self.send_response(200)
						self.send_header('Content-Type', "application/json")
						self.end_headers()
					else:
						self.send_error(400, 'request param cannot be null')
				else:
					self.send_error(404, 'url not found')
			except BaseException as e:
				log.exception('callback rs weight failed %s, trackback: %s' % (e, traceback.format_exc()))
				self.send_error(500, 'callback rs weight failed')

	if os.path.exists(MESOS_API_SOCKET_PATH):
		os.remove(MESOS_API_SOCKET_PATH)
	server = UnixSocketHttpServer(MESOS_API_SOCKET_PATH, myHandler)
	server.serve_forever()


class MesosHandler(BaseHTTPRequestHandler):
		detector = Detector.detector_result

		def do_POST(self):
			try:
				if self.path == "/detect_result":
					# get request body
					request = self.rfile.read(int(self.headers.getheader('content-length')))
					request_body = json.loads(request)
					if not request_body['switch'] : # true: mesos control bird, false: mesos not control bird
						Detector.last_call_time = MesosHandler.detector.datetime_now()
					# detect_result
					self.send_response(200)
					self.send_header('Content-Type', "application/json")
					self.end_headers()
					self.wfile.write(MesosHandler.detector.get_detect_result())
				elif self.path == "/execute_bird":
					# get request body
					request = self.rfile.read(int(self.headers.getheader('content-length')))
					request_body = json.loads(request)
					if request_body['type'] == "start":
						if os.path.exists(Detector.DPVS_UPGRADING_FILE):
							log.info('DPVS_UPGRADING_FILE %s exist, will not start Bird' % Detector.DPVS_UPGRADING_FILE )
							return
						if not Detector.ensure_dpvs_has_session():
							log.error('dpvs has no sync session record')
							return
						try:
							if FullnatConfig.IS_STANDARD_CLUSTER:
								bird_start_func = Bird.multi_stage_advertise
							else:
								bird_start_func = Bird.start

							if bird_start_func():
								self.send_response(200)
								self.send_header('Content-Type', "application/json")
								self.end_headers()
								self.wfile.write('{"success":true, "result":"start bird ok"}')
							else:
								log.info('start bird failed')
								self.send_error(400, 'start bird failed')
						except BaseException as e:
							log.error('got exception when start bird %s' % e)
					elif request_body['type'] == "stop":
						try:
							if Bird.stop_with_lock():
								self.send_response(200)
								self.send_header('Content-Type', "application/json")
								self.end_headers()
								self.wfile.write('{"success":true, "result":"stop bird ok"}')
							else:
								log.info('stop bird failed')
								self.send_error(400, 'stop bird failed')
						except BaseException as e:
							log.error('got exception when stop bird %s' % e)
					else:
						self.send_error(400, 'request type should be start or stop')
				else:
					self.send_error(404, 'url not found')
			except SystemExit as e:
				log.exception('mesos API execute failed: %s, shopee-mesos-dpvs will quit, traceback: %s' % (e, traceback.format_exc()))
				self.send_error(500, 'mesos API execute failed: ' + str(e))
				os._exit(255)  # 立即终止进程(而非仅终止线程)，注意：这种方式不执行任何清理
			except BaseException as e:
				log.exception('mesos API execute failed: %s, traceback: %s' % (e, traceback.format_exc()))
				self.send_error(500, 'mesos API execute failed')


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
	"""Handle requests in a separate thread."""


class MesosServer(object):
	MESOS_PORT = 9124

	def run(self):
		httpd = ThreadedHTTPServer(('0.0.0.0', self.MESOS_PORT), MesosHandler)
		httpd.serve_forever()


def install_signal_handlers(dpvs):
	def pause_handler(signum, frame):
		dpvs.disable_sync()

	def resume_handler(signum, frame):
		dpvs.enable_sync()

	signal.signal(signal.SIGUSR1, pause_handler)
	signal.signal(signal.SIGUSR2, resume_handler)


def _fullnat():
	load_config('fullnat')
	dpvs = FullnatDPVS()
	install_signal_handlers(dpvs)
	tasks = [gevent.spawn(dpvs.run_loop)]
	if not GetMesosHCMod.IS_MESOS_WITH_HC:
		tasks.append(gevent.spawn(api_run, dpvs))
	server = MesosServer()
	server.run()
	gevent.joinall(tasks)


@cli.command()
def fullnat():
	return _fullnat()
