# -*- coding: UTF-8 -*-
from shopee_deploy import utils
import logging as log
import logging.config as log_config

# Override logger from shopee_deploy.
utils.IS_LOGGER_INIT = True

env = utils.read_file('/etc/mesos-dpvs/env').strip()
log_dir = '/data/log/dpvs-daemon-%s-sg/' % env
config = {
	'loggers': {
		'main': {
			'level': 'DEBUG',
			'propagate': True,
			'handlers': ['file_fatal', 'file_error', 'file_info']
		},
		'data': {
			'level': 'DEBUG',
			'propagate': True,
			'handlers': ['file_data']
		},
	},
	'disable_existing_loggers': True,
	'handlers': {
		'file_data': {
			'backupCount': 30,
			'level': 'DEBUG',
			'encoding': None,
			'when': 'MIDNIGHT',
			'filename': '%s/data.log' % (log_dir, ),
			'formatter': 'data',
			'class': 'logging.handlers.TimedRotatingFileHandler'
		},
		'file_error': {
			'backupCount': 30,
			'level': 'WARNING',
			'encoding': None,
			'when': 'MIDNIGHT',
			'filename': '%s/error.log' % (log_dir, ),
			'formatter': 'standard',
			'class': 'logging.handlers.TimedRotatingFileHandler'
		},
		'file_info': {
			'backupCount': 30,
			'level': 'DEBUG',
			'encoding': None,
			'when': 'MIDNIGHT',
			'filename': '%s/info.log' % (log_dir, ),
			'formatter': 'standard',
			'class': 'logging.handlers.TimedRotatingFileHandler'
		},
		'file_fatal': {
			'backupCount': 30,
			'level': 'CRITICAL',
			'encoding': None,
			'when': 'MIDNIGHT',
			'filename': '%s/fatal.log' % (log_dir, ),
			'formatter': 'standard',
			'class': 'logging.handlers.TimedRotatingFileHandler'
		}
	},
	'formatters': {
		'short': {
			'datefmt': '%Y-%m-%d %H:%M:%S',
			'format': '%(asctime)s.%(msecs)03d|%(levelname)s|%(message)s'
		},
		'data': {
			'datefmt': '%Y-%m-%d %H:%M:%S',
			'format': '%(asctime)s.%(msecs)03d|%(message)s'
		},
		'standard': {
			'datefmt': '%Y-%m-%d %H:%M:%S',
			'format': '%(asctime)s.%(msecs)03d|%(levelname)s|%(process)d:%(thread)d|%(filename)s:%(lineno)d|%(module)s.%(funcName)s|%(message)s'
		}
	},
	'version': 1,
	'filters': {}
}


def append_exc(func):
	def _append_exc(*args, **kwargs):
		if 'exc_info' not in kwargs:
			kwargs['exc_info'] = True
			return func(*args, **kwargs)
	return _append_exc


log_config.dictConfig(config)
log.root = log.getLogger('main')
log.exception = append_exc(log.error)
log.assertion = log.critical
log.data = log.getLogger('data').info
