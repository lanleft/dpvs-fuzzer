# -*- coding: UTF-8 -*-
from shopee_deploy.utils import get_command_output
from filelock import FileLock
import traceback
from logger import log
from packaging.version import Version, InvalidVersion
import os
import sys

_lock = FileLock('/tmp/_dpvs_command.lock')
ERROR_RES = 'error_res'


def get_command_output_with_lock(command, env=None, merge_stderr=False, exit_on_fail=True):
	with _lock:
		ret = ERROR_RES

		try:
			ret = get_command_output(command, env=env, merge_stderr=merge_stderr)
		except Exception as e:
			debug_msg = traceback.format_exc()
			if exit_on_fail:
				log.error('execute_command_failed|exiting|command=%s,traceback=%s', command, debug_msg)
				sys.exit(-1)
			else:
				log.error('execute_command_failed|ignoring|command=%s,traceback=%s', command, debug_msg)
		return ret


def touch(fname, times=None):
	log.info('touch %s' % fname)
	with open(fname, 'a'):
		os.utime(fname, times)

class GenericFunction:
	@staticmethod
	def is_service_active(service_name):
		command = 'systemctl is-active %s' % service_name
		output = get_command_output_with_lock(command, exit_on_fail=False).strip()
		if output == 'active':
			return True
		else:
			return False
	@staticmethod
	def is_service_activating(service_name):
		command = 'systemctl is-active %s' % service_name
		output = get_command_output_with_lock(command, exit_on_fail=False).strip()
		if output in ['active', 'activating']:
			return True
		else:
			return False
	@staticmethod
	def list_filenames(path):
		# 获取指定路径下的所有文件（不包括文件夹）
		all_items = os.listdir(path)
		# 过滤出文件名
		filenames = [item for item in all_items if os.path.isfile(os.path.join(path, item))]
		return filenames
	@staticmethod
	def get_dpvs_version():
		try:
			# 与pal-shell的区别：这个是系统调用，不受dpvs启动状态的影响
			return Version(get_command_output_with_lock("dpkg -s dpvs-shopee | awk '$1~/^Version:/{print $2}' | awk -F'+' '{print $1}'", exit_on_fail=False).strip())
		except InvalidVersion:
			return Version("0")