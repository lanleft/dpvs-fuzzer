# -*- coding: UTF-8 -*-
from __future__ import print_function
import gevent
import json
import stopit
import sccclient
import socket
import time
import traceback
import unittest
from .logger import log
from shopee_deploy.utils import ensure_file_exists, read_file, write_file


component_name = "shopee-mesos-dpvs"

current_module_name = "nlb-agent"

LIVE = "live"
# NONLIVE = "test"

GLOBAL = "global"

live_env_list = ["live", "liveish"]
nonlive_env_list = ["test", "uat", "stable", "staging"]

# todo: 部分集群的环境变量 env=test 但视为现网集群；这类处理方式不够灵活，有待优化，nlb-sd 同理
cluster_uuid_belong_to_live = [
    "37c76397-11f3-50eb-ae62-dab4874c9924",  # nlb.stdlan1.test.sg88
    "c4c58098-3697-5bcb-904d-a79ae72aaff8",  # nlb.stdwan1.test.sg88
    "9dbe5ec2-d538-58ef-82bf-51d51916247a",  # sg2.test
    "17b708c1-3517-5b89-983c-83c0c2421d9f",  # standard1.fullnat-servers.sg2.test
    "77bf65b8-a3c5-5aca-8e9b-7d939dc2ccae",  # sg2.staging
    "715338cd-a287-5766-b31d-d5e060cbe965",  # sg2.stable
]
cluster_name_belong_to_live = [
    "nlb.stdlan1.test.sg88",
    "nlb.stdwan1.test.sg88",
    "sg2.test",
    "standard1.fullnat-servers.sg2.test",
    "sg2.staging",
    "sg2.stable",
]

env_to_secret = {
    "live": "2acda191de07b20497acfa22c9298d416c8b288c7ac034bf0b3fa05c80ebe09f",
    "nonlive": "7157b87229c7ca282010d99fce7171c5de0908982061a6d36b40bd794523102d"
}


class ValueSource:
    def __init__(self):
        pass

    CALLER = 'caller'
    DEFAULT = 'default'
    AZ = 'az'
    CLUSTER = 'cluster'
    NODE = 'node'


class ConfigCenter:
    IDENTITY = "sgw_l4"

    client = None
    namespace = None
    dispose = None

    @staticmethod
    def get_az():
        try:
            with open('/etc/tocex/labels.json', 'r') as f:
                labels = json.load(f)
                az = labels.get('az', None)
                az_v2 = labels.get('az_v2', None)
                return az_v2 if az_v2 else az
        except Exception as e:
            return None

    @staticmethod
    def get_cluster_uuid():
        try:
            with open('/etc/mesos-dpvs/fullnat.json', 'r') as f:
                fullnat_config = json.load(f)
                return fullnat_config.get('cluster_uuid', None)
        except Exception as e:
            return None

    @staticmethod
    def get_cluster_name():
        try:
            with open('/etc/mesos-dpvs/cluster', 'r') as f:
                cluster_name = f.read()
                return cluster_name
        except Exception as e:
            return None

    @staticmethod
    def get_host_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.0.0.1", 1))
        ip = s.getsockname()[0]
        return ip

    @staticmethod
    def get_env():
        try:
            with open('/etc/tocex/labels.json', 'r') as f:
                labels = json.load(f)
                return labels.get('env', None)
        except Exception as e:
            return None

    @classmethod
    def get_environment(cls):
        env = ConfigCenter.get_env()
        cluster_uuid = ConfigCenter.get_cluster_uuid()
        cluster_name = ConfigCenter.get_cluster_name()
        if env in live_env_list:
            return LIVE
        if env in nonlive_env_list:
            if cluster_uuid in cluster_uuid_belong_to_live:
                return LIVE
            if cluster_name in cluster_name_belong_to_live:
                return LIVE
            return env
        return LIVE

    @classmethod
    def get_secret_string(cls):
        env = ConfigCenter.get_env()
        if env in live_env_list:
            return env_to_secret.get("live")
        if env in nonlive_env_list:
            return env_to_secret.get("nonlive")
        return env_to_secret.get("live")

    def set_namespace_and_secret_string(self):
        self.namespace_string = '_'.join([self.module_name, self.get_environment(), GLOBAL])
        self.secret_string = self.get_secret_string()
        log.info('namespace: %s', self.namespace_string)

    def __init__(self, module_name, namespace_string="", secret_string=""):
        self.module_name = module_name
        self.node = ConfigCenter.get_host_ip()
        self.cluster = ConfigCenter.get_cluster_uuid()
        if not self.cluster:
            self.cluster = ConfigCenter.get_cluster_name()
        self.az = ConfigCenter.get_az()

        self.namespace_string = namespace_string
        self.secret_string = secret_string
        if not self.namespace_string or not self.secret_string:
            self.set_namespace_and_secret_string()

        self.local_config_file = "/etc/mesos-dpvs/" + component_name + '/' + self.namespace_string + ".json"

        try:
            with stopit.ThreadingTimeout(3) as to_ctx_mgr:
                self.client = sccclient.Client()
                self.namespace, self.dispose = self.client.subscribe(
                    sccclient.NamespaceIdentity(ConfigCenter.IDENTITY, self.namespace_string),
                    sccclient.NamespaceSecret(self.secret_string))
            if to_ctx_mgr.state == to_ctx_mgr.TIMED_OUT:
                raise Exception("Failed to init config center client: timeout")
        except Exception as e:
            log.error('got exception: %s when subscribe config center, traceback=%s', e, traceback.format_exc())
            self.namespace = sccclient.Namespace()
            # 启动协程自动重试订阅
            gevent.spawn(self.try_subscribe, self.namespace_string, self.secret_string)

    def try_subscribe(self, namespace_string, secret_string):
        while True:
            try:
                time.sleep(3)
                with stopit.ThreadingTimeout(3) as to_ctx_mgr:
                    client = sccclient.Client()
                    namespace, dispose = client.subscribe(
                        sccclient.NamespaceIdentity(ConfigCenter.IDENTITY, namespace_string),
                        sccclient.NamespaceSecret(secret_string))
                if to_ctx_mgr.state == to_ctx_mgr.TIMED_OUT:
                    raise Exception("Failed to init config center client: timeout")
            except Exception as e:
                log.error('got exception: %s when subscribe config center, traceback=%s', e, traceback.format_exc())
                continue

            # Process result.
            self.client, self.namespace, self.dispose = client, namespace, dispose
            break

    def __del__(self):
        if self.dispose:
            self.dispose()
        if self.client:
            self.client.close()

    def print(self):
        print(self.namespace_string)
        print(self.secret_string)
        print(self.node)
        print(self.cluster)
        print(self.az)

    def set_node(self, cluster, node, az=None):
        self.cluster = cluster
        self.node = node
        if az:
            self.az = az

    def snapshot(self):
        return self.namespace.snapshot()

    def items(self):
        return self.snapshot().items()

    def snapshot_dump(self):
        items = self.items()
        for k, v in items:
            print(k)
            print(json.dumps(v, indent=4, sort_keys=True) if isinstance(v, dict) else str(v))

    def keys(self):
        return self.snapshot().keys()

    def get(self, key, value=None):
        """
        snapshot 会缓存在本地，从 snapshot 中读取数据；
        正常情况下，snapshot 会随 config center 的写事件自动更新；
        但某些异常情况下，snapshot 不会自动更新，只能通过重启服务以获取最新配置；
        """
        return self.snapshot().get(key, value)

    def get_precise(self, key, value=None):
        # try to get default value from default item
        get_from_config_center_success = False
        try:
            val, src = self.get('default')[key], ValueSource.DEFAULT
            get_from_config_center_success = True
        except Exception as e:
            return value, ValueSource.CALLER

        # try to get value from key config item
        try:
            v = self.get(key)
            try:
                val, src = v['azs'][self.az], ValueSource.AZ
            except Exception as e:
                pass
            try:
                val, src = v['clusters'][self.cluster]['default'], ValueSource.CLUSTER
            except Exception as e:
                pass
            val, src = v['clusters'][self.cluster]['nodes'][self.node], ValueSource.NODE
        except Exception as e:
            pass

        if get_from_config_center_success:
            self.update_local_config(key, val)

        return val, src

    def load_local_config(self):
        ensure_file_exists(self.local_config_file)
        content = read_file(self.local_config_file)
        config = {}
        if content:
            config = json.loads(content)
        return config

    def update_local_config(self, key, value):
        config = self.load_local_config()
        config.update({key: value})
        write_file(self.local_config_file, json.dumps(config, indent=4, sort_keys=True))

    def get_from_local_config(self, key, value):
        config = self.load_local_config()
        return config.get(key, value)


module_config = ConfigCenter(current_module_name)


class TestConfigCenter(unittest.TestCase):
    config_center = None

    @classmethod
    def setup_class(cls):
        cls.config_center = ConfigCenter("dpvs-shopee", "dpvs-shopee_test_global", "256edaec2337c52e7d5cd8c7b0e9ed434e5671a1a6c4d723db6eb1c3231d6c8e")

    @classmethod
    def teardown_class(cls):
        del cls.config_center

    def test_set_node(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.cluster, '9f0e0857-2e80-537c-8819-7840bce06c30')
        self.assertEqual(self.config_center.node, '10.2.2.2')
        self.assertEqual(self.config_center.az, 'sg2')

        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c31', '10.2.2.3')
        self.assertEqual(self.config_center.cluster, '9f0e0857-2e80-537c-8819-7840bce06c31')
        self.assertEqual(self.config_center.node, '10.2.2.3')
        self.assertEqual(self.config_center.az, 'sg2')

    def test_get_precise_1(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 1, u'max_duration_time': 900, u'max_syn_backlog': 16384}, 'node'))

    def test_get_precise_2(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.3', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 0, u'max_duration_time': 900, u'max_syn_backlog': 524288}, 'cluster'))

    def test_get_precise_3(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', None, 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 0, u'max_duration_time': 900, u'max_syn_backlog': 524288}, 'cluster'))

    def test_get_precise_4(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c31', '10.2.2.2', 'us2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 2, u'max_duration_time': 900, u'max_syn_backlog': 16384}, 'az'))

    def test_get_precise_5(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c31', '10.2.2.3', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 2, u'max_duration_time': 900, u'max_syn_backlog': 524288}, 'default'))

    def test_get_precise_6(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch2'), (None, 'caller'))

    def test_get_precise_7(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c32', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 2, u'max_duration_time': 30, u'max_syn_backlog': 524288}, 'cluster'))

    def test_get_precise_8(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c32', '10.2.2.3', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 2, u'max_duration_time': 30, u'max_syn_backlog': 524288}, 'cluster'))

    def test_get_precise_9(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c32', '10.2.2.2', 'us2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch'), ({u'global_switch': 2, u'max_duration_time': 30, u'max_syn_backlog': 524288}, 'cluster'))

    def test_get_precise_10(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c32', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('synproxy_switch2'), (None, 'caller'))

    def test_get_precise_11(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('sync_dpdk_mode'), (False, 'default'))

    def test_get_precise_12(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.3', 'sg2')
        self.assertEqual(self.config_center.get_precise('sync_dpdk_mode'), (False, 'default'))

    def test_get_precise_13(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c31', '10.2.2.2', 'us2')
        self.assertEqual(self.config_center.get_precise('sync_dpdk_mode'), (False, 'default'))

    def test_get_precise_14(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('sync_dpdk_mode'), (False, 'default'))

    def test_get_precise_15(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('sync_dpdk_mode2'), (None, 'caller'))

    def test_get_precise_16(self):
        self.config_center.set_node('9f0e0857-2e80-537c-8819-7840bce06c30', '10.2.2.2', 'sg2')
        self.assertEqual(self.config_center.get_precise('default'), (None, 'caller'))


if __name__ == "__main__":
    unittest.main()
