# -*- coding: UTF-8 -*-
import os
import json

from shopee_deploy.utils import execute, read_file, \
	generate_content_by_template, write_file
from shopee_mesos_dpvs.detector import Detector

from .fullnat import DPVS, DPIPHelper, IPWithMask, Route
from .bird import Bird
from .config import load_config, get_config
from .base import cli, IPVSAdminHelper, SnatServerFactory, NATMode
from .logger import log

class SnatDPVS(DPVS):

	def __init__(self):
		super(self.__class__, self).__init__()
		self.config = get_config()
		self._nics = []
		self._snat_servers_snapshot = None

		# Need to check whether bird is enabled because
		# Detector will try to start/stop bird
		if self.config.is_bird_enabled:
			Detector.start(self.config, NATMode.SNAT)

	def reset(self):
		self._nics = []
		self._snat_servers_snapshot = None

	def config_lan_vlan(self, nics):
		if len(self.config.lan_nic.split('.')) > 1:
			lan_origin_nic, lan_vlan_id = self.config.lan_nic.split('.')
			DPIPHelper.add_vlan(lan_origin_nic, lan_vlan_id, nics=nics)

	def config_ips(self, nics):
		DPIPHelper.add_ip(self.config.lan_nic, IPWithMask(self.config.lan_inner_ip, mask=self.config.lan_mask), nics=nics)

	def config_routes(self, nics):
		# in case of lan/wan switch both are start with 10 and default route rule to wan switch will be invalid
		if not self.config.wan_switch_ip.startswith('10.'):
			DPIPHelper.add_route(self.config.lan_nic, Route('10.0.0.0', 8, gateway=self.config.lan_switch_ip), nics=nics)
		DPIPHelper.add_route(self.config.wan_nic, Route('0.0.0.0', 0, gateway=self.config.wan_switch_ip), nics=nics)

		for route in self.config.custom_routes:
			DPIPHelper.add_route(self.config.lan_nic, Route(route['dst'], route['netmask'], gateway=route['gateway']), nics=nics)

	def config_bird(self):
		bird_template_file = os.path.join(os.path.dirname(__file__), 'res', 'bird_snat.conf.j2')

		content = generate_content_by_template(
			bird_template_file,
			wan_mask=self.config.wan_mask,
			wan_switch_ip=self.config.wan_switch_ip,
			has_wan_nic=self.has_wan_nic(),
			lan_inner_ip=self.config.lan_inner_ip,
			lan_mask=self.config.lan_mask,
			lan_switch_ip=self.config.lan_switch_ip,
			lan_switch_as=self.config.lan_switch_as,
			lan_nic=self.config.lan_nic,
		)

		return Bird.update_config_and_reload(content)

	def sync_snat_servers(self):
		# TODO: Change to same as FullnatDPVS.sync_virtual_servers.
		snat_servers = SnatServerFactory.load()

		snat_servers_snapshot = json.dumps(
			[ss.to_dict() for ss in snat_servers],
			sort_keys=True,
		)
		if self._snat_servers_snapshot != snat_servers_snapshot:
			current_snat_servers = IPVSAdminHelper.get_snat_servers()
			if current_snat_servers is None:
				log.error('fail to get snat vs list')
				return
			# Avoid call unnecessary ipvsadm.
			IPVSAdminHelper.update_snat_servers(
				snat_servers,
				self.config.wan_nic,
				self.config.src_range,
				current_snat_servers
			)
			self._snat_servers_snapshot = snat_servers_snapshot

	def get_virtual_servers(self):
		try:
			return json.loads(self._snat_servers_snapshot)
		except:
			return None
	def post_up(self):
		nics = DPIPHelper.get_nics()

		self.config_lan_vlan(nics)
		self.config_ips(nics)
		self.config_routes(nics)
		if self.config.is_bird_enabled:
			self.config_bird()

	def run(self):
		self.sync_snat_servers()

	def has_wan_nic(self):
		if not self.config.wan_nic:
			return False
		return True


def _snat():
	load_config('snat')
	dpvs = SnatDPVS()
	return dpvs.run_loop()


@cli.command()
def snat():
	return _snat()
