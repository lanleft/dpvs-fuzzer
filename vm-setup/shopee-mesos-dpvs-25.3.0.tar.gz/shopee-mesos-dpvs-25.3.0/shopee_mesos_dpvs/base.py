# -*- coding: UTF-8 -*-
import traceback
from distutils.util import strtobool

import click
import json
import time
import re
import os

import ipaddress
import psutil
from shopee_deploy.utils import execute, read_file, write_file

from .command import ERROR_RES, get_command_output_with_lock, GenericFunction
from .config import FullnatConfig, get_config
from .config import reset_node_config_change_flags, module_config
from .logger import log
from .bird import Bird
from enum import Enum

from shopee_mesos_dpvs import command
from threading import Lock
import IPy
from packaging.version import Version

class VNI(object):
	UNDERLAY_DEFAULT_VNI = '-1'

class IPWithMask(object):

	ORIGIN_REF_COUNT = 2
	FIELD_SEPARATOR = u','

	def __init__(self, ip, mask=32, vni=VNI.UNDERLAY_DEFAULT_VNI, ref_count=ORIGIN_REF_COUNT, option='', ignore_del_err=False):
		self.ip = ip
		self.mask = mask
		self.vni = vni
		self.ref_count = ref_count
		self.option = option
		self.ignore_del_err = ignore_del_err

	def to_dict(self):
		return {
			'ip': self.ip,
			'mask': self.mask,
			'vni': self.vni,
		}

	# ref_count is not included cause its not depend on config, but traffic
	def __hash__(self):
		field_list = [self.ip, str(self.mask), self.vni]
		return hash(IPWithMask.FIELD_SEPARATOR.join(field_list))

	def __eq__(self, other):
		if isinstance(other, self.__class__):
			return (self.ip, str(self.mask), self.vni) == (other.ip, str(other.mask), other.vni)
		else:
			return False

	# https://docs.python.org/2.7/reference/datamodel.html?highlight=hash#object.__ne__
	def __ne__(self, other):
		return not self.__eq__(other)

	@classmethod
	def cast_from_ips(cls, ips, mask=32, vni=VNI.UNDERLAY_DEFAULT_VNI, ignore_del_err=False):
		tmp = set()
		for ip in ips:
			tmp.add(IPWithMask(ip, mask, vni, ignore_del_err=ignore_del_err))
		return tmp

class Route(object):
	# TODO: support custom hash
	def __init__(self, ip, mask, gateway='0.0.0.0'):
		self.ip = ip
		self.mask = mask
		self.gateway = gateway

	def to_dict(self):
		return {
			'ip': self.ip,
			'mask': self.mask,
			'gateway': self.gateway,
		}


class Nic(object):

	def __init__(self, name=None, mac=None, device_id=None, ip_with_masks=None, routes=None):
		self.name = name
		self.mac = mac
		self.device_id = device_id
		self.ip_with_masks = ip_with_masks if ip_with_masks is not None else []
		self.routes = routes if routes is not None else []

	def to_dict(self):
		return {
			'name': self.name,
			'mac': self.mac,
			'device_id': self.device_id,
			'ip_with_masks': [ip_with_mask.to_dict() for ip_with_mask in self.ip_with_masks],
			'routes': [route.to_dict() for route in self.routes],
		}


class NATMode(Enum):
	SNAT = 1
	FULLNAT = 2


class DPIPHelper(object):
	new_addr_set = set()

	@classmethod
	def get_nics(cls):
		output = get_command_output_with_lock('dpip -v link show').split('\n')
		# Match '2: dpdk1: socket 0 mtu 1500 rx-queue 8 tx-queue 8'
		nic_pattern = re.compile(r'^\d+:\s+(?P<nic>[\w.]+):\s+socket')
		# Match '0000:04:00:1                    net_ixgbe'
		device_id_pattern = re.compile(r'^\s+(?P<device_id>0000:\d{2}:\d{2}:\d)')

		nics = []
		for line in output:
			match = nic_pattern.match(line)
			if match:
				nic = {
					'name': match.group('nic')
				}
				nics.append(nic)
				continue

			match = device_id_pattern.match(line)
			if match:
				nics[-1]['device_id'] = match.group('device_id')
				continue

		nic_map = {}
		for nic in nics:
			nic_map[nic['name']] = Nic(**nic)

		cls.get_addr(nic_map)
		cls.get_route(nic_map)

		return nic_map

	@classmethod
	def get_addr(cls, nic_map):
		output = get_command_output_with_lock('dpip addr show').split('\n')
		# Match 'inet vni=0,103.223.1.74/32 scope global dpdk0'.
		ip_with_mask_pattern = re.compile(
			r'^.*inet\s+(vni=(?P<vni>\d+),)?(?P<ip>[\d.]+)/(?P<mask>\d+).*\s+global\s+(?P<nic>[\w.]+)')
		ref_count_pattern = re.compile(r'.*refcnt\((?P<ref_count>\d+)\).*')

		for nic in nic_map:
			nic_map[nic].ip_with_masks = []

		nic = ''
		for line in output:
			match = ip_with_mask_pattern.match(line)
			if match:
				nic = match.group('nic')
				ip = match.group('ip')
				mask = int(match.group('mask'))
				vni = match.group('vni') if match.group('vni') else VNI.UNDERLAY_DEFAULT_VNI
				nic_map[nic].ip_with_masks.append(IPWithMask(ip, mask, vni))
				continue
			match = ref_count_pattern.match(line)
			if match:
				nic_map[nic].ip_with_masks[-1].ref_count = int(match.group('ref_count'))

	@classmethod
	def get_route(cls, nic_map):
		# 重置nic的路由数据表，nic_map非并发安全
		output = get_command_output_with_lock('dpip route show').split('\n')
		# Match 'inet 103.223.1.74/32 via 0.0.0.0 src 0.0.0.0 dev dpdk0 mtu 1500 tos 0 scope host metric 0 proto auto'.
		route_pattern = re.compile(
			r'^inet\s+(?P<ip>[\d.]+)/(?P<mask>\d+)\s+via\s+(?P<gateway>[\d.]+)\s+src\s+[\d.]+\s+dev\s+(?P<nic>[\w.]+)\s+.*')

		for nic in nic_map:
			nic_map[nic].routes = []

		for line in output:
			match = route_pattern.match(line)
			if match:
				nic = match.group('nic')
				ip = match.group('ip')
				mask = int(match.group('mask'))
				gateway = match.group('gateway')
				nic_map[nic].routes.append(Route(ip, mask, gateway))

	@classmethod
	def add_vlan(cls, origin_nic, vlan_id, nics=None):
		if nics is None:
			nics = cls.get_nics()

		if '%s.%s' % (origin_nic, vlan_id) not in nics:
			execute('dpip vlan add link %s id %s' % (origin_nic, vlan_id))

			nic = '%s.%s' % (origin_nic, vlan_id)
			nics[nic] = Nic(name=nic, mac=nics[origin_nic].mac, device_id=nics[origin_nic].device_id)

	@classmethod
	def add_ip(cls, nic, ip_with_mask, nics=None):
		if nics is None:
			nics = cls.get_nics()
		if not nic:
			log.exception('invalid nic in add_ip, nic:%s, ip_with_mask: %s' % (nic, ip_with_mask.to_dict()))
			return

		found_ip_with_mask = False
		for _ip_with_mask in nics[nic].ip_with_masks:
			if _ip_with_mask.ip == ip_with_mask.ip and _ip_with_mask.mask == ip_with_mask.mask:
				found_ip_with_mask = True

		if not found_ip_with_mask:
			vni_cmd = '' if ip_with_mask.vni == VNI.UNDERLAY_DEFAULT_VNI else 'vni=%s,' % ip_with_mask.vni
			execute('dpip addr add %s%s/%s dev %s %s' % (
				vni_cmd,
				ip_with_mask.ip,
				ip_with_mask.mask,
				nic,
				ip_with_mask.option,
			))
			nics[nic].ip_with_masks.append(ip_with_mask)

	@classmethod
	def del_ip(cls, ip_with_mask, nic_name):
		if ip_with_mask.ref_count > IPWithMask.ORIGIN_REF_COUNT:
			log.info("ip: %s ref_cnt: %s > %s, quit delete" % (ip_with_mask.ip, ip_with_mask.ref_count, IPWithMask.ORIGIN_REF_COUNT))
			return
		vni_param = '' if ip_with_mask.vni==VNI.UNDERLAY_DEFAULT_VNI else 'vni=%s,'%ip_with_mask.vni
		execute('dpip addr del %s%s/%s dev %s' % (
			vni_param,
			ip_with_mask.ip,
			ip_with_mask.mask,
			nic_name,
		), exit_on_fail=False) # 这里不用ignore_del_err的原因是要考虑有会话时删除lip报错的场景，目前的ip对账没有很优雅的方式来区分是否是lip

	@classmethod
	def add_route(cls, nic, route, nics=None):
		if nics is None:
			nics = cls.get_nics()

		found_route = False
		for _route in nics[nic].routes:
			if _route.ip == route.ip and _route.mask == route.mask:
				found_route = True
		if found_route:
			log.error('route: %s/%s, dev: %s exists, skip add' % (route.ip, route.mask, nic))
			return
		else:
			if route.mask == 0:
				subnet = 'default'
			else:
				subnet = '%s/%s' % (route.ip, route.mask,)
			execute('dpip route add %s via %s dev %s' % (
				subnet,
				route.gateway,
				nic,
			))
			nics[nic].routes.append(route)

	@classmethod
	def del_route(cls, nic, route, nics=None):
		if nics is None:
			nics = cls.get_nics()
		
		new_routes = []
		found_route = False
		for _route in nics[nic].routes:
			if _route.ip == route.ip and _route.mask == route.mask:
				found_route = True
			else:
				new_routes.append(_route)
		if not found_route:
			log.error('route: %s/%s, dev: %s not exists, skip del' % (route.ip, route.mask, nic))
			return
		if route.mask == 0:
			subnet = 'default'
		else:
			subnet = '%s/%s' % (route.ip, route.mask,)
		execute('dpip route del %s via %s dev %s' % (
			subnet,
			route.gateway,
			nic,
		))
		nics[nic].routes = new_routes

	@classmethod
	def dump_addr(cls):
		fd = os.popen("dpip addr show")
		all_ip_list = re.findall(r'\d+\.\d+\.\d+\.\d+', fd.read())
		fd.close()
		return all_ip_list

class IPHelper(object):
	nics = {}
	@staticmethod
	def get_nics():
		nic_map = {}
		output = get_command_output_with_lock('ip link show').split('\n')
		# Match '55: dpdk0.kni: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP mode DEFAULT group default qlen 1000'
		nic_pattern = re.compile(r'^\d+:\s+(?P<nic>[\w.]+):\s+')
		for line in output:
			match = nic_pattern.match(line)
			if match:
				name = match.group('nic')
				nic_map[name] = Nic(name=name)

		IPHelper.get_addr(nic_map)
		IPHelper.nics = nic_map
		return

	@staticmethod
	def get_addr(nic_map):
		output = get_command_output_with_lock('ip -4 addr show').split('\n')
		# Match 'inet 103.223.1.74/32 scope global dpdk0'.
		ip_with_mask_pattern = re.compile(r'^.*inet\s+(?P<ip>[\d.]+)/(?P<mask>\d+).*\s+global\s+(?P<nic>[\w.]+)')

		for line in output:
			match = ip_with_mask_pattern.match(line)
			if match:
				nic = match.group('nic')
				ip = match.group('ip')
				mask = int(match.group('mask'))
				if nic not in nic_map:
					nic_map[nic] = Nic(name=nic)
				nic_map[nic].ip_with_masks.append(IPWithMask(ip, mask))
		return

	@staticmethod
	def add_ip(nic, ip_with_mask):
		nics = IPHelper.nics
		found_ip_with_mask = False

		if nic not in nics:
			execute('ip link set %s up' % nic)
		else:
			for _ip_with_mask in nics[nic].ip_with_masks:
				if _ip_with_mask.ip == ip_with_mask.ip and _ip_with_mask.mask == ip_with_mask.mask:
					found_ip_with_mask = True
					break

		if not found_ip_with_mask:
			subnet = ipaddress.IPv4Network('%s/%s' % (ip_with_mask.ip, ip_with_mask.mask), False)
			execute('ip link set %s up' % nic)
			execute('ip addr add %s/%s brd %s dev %s' % (
				ip_with_mask.ip,
				ip_with_mask.mask,
				subnet.broadcast_address,
				nic,
			))
	@staticmethod
	def del_ip(nic, ip_with_mask):
		nics = IPHelper.nics
		found_ip_with_mask = False
		if nic not in nics:
			execute('ip link set %s up' % nic)
		else:
			for _ip_with_mask in nics[nic].ip_with_masks:
				if _ip_with_mask.ip == ip_with_mask.ip and _ip_with_mask.mask == ip_with_mask.mask:
					found_ip_with_mask = True
					break

		if found_ip_with_mask:
			subnet = ipaddress.IPv4Network('%s/%s' % (ip_with_mask.ip, ip_with_mask.mask), False)
			execute('ip link set %s up' % nic)
			execute('ip addr del %s/%s brd %s dev %s' % (
				ip_with_mask.ip,
				ip_with_mask.mask,
				subnet.broadcast_address,
				nic,
			))

	@staticmethod
	def is_internal_ip(ip):
		if ip in IPy.IP('10.0.0.0/8'):
			return True
		elif ip in IPy.IP('172.16.0.0/12'):
			return True
		elif ip in IPy.IP('192.168.0.0/16'):
			return True
		return False


class RealServer(object):

	def __init__(self, ip, port, origin_weight, effective_weight, vni=VNI.UNDERLAY_DEFAULT_VNI):
		self.ip = ip
		self.port = port
		self.origin_weight = origin_weight
		self.effective_weight = effective_weight
		self.vni = str(vni)

		self.config = get_config()

		self.success_count = 0
		self.fail_count = 0
		self.up = True

	def to_dict(self):
		# Ignore `origin_weight`, `config`, `success_count`, `fail_count` since
		# they didn't affect DPVS traffic forwarding rules generation.
		return {
			'ip': self.ip,
			'port': self.port,
			'effective_weight': self.effective_weight,
			'up': self.up,
			'vni': self.vni,
		}

	def success(self):
		self.success_count += 1
		if self.success_count > self.config.status_change_limit and self.effective_weight != self.origin_weight:
			self.effective_weight = self.origin_weight
			self.up = True
			log.info(
				'real_server_marked_success|ip=%s,port=%s,effective_weight=%s',
				self.ip,
				self.port,
				self.effective_weight,
			)
		self.fail_count = 0

	def fail(self):
		self.fail_count += 1
		if self.fail_count > self.config.status_change_limit and self.effective_weight > 0:
			self.effective_weight = 0
			self.up = False
			log.error(
				'real_server_marked_fail|ip=%s,port=%s,effective_weight=%s',
				self.ip,
				self.port,
				self.effective_weight,
			)
		self.success_count = 0

	def enable_temporary(self):
		# enable_temporary when all real server down.
		if GetMesosHCMod.IS_MESOS_WITH_HC:
			if self.fail_count > self.config.status_change_limit and self.effective_weight == 0:
				self.effective_weight = 101
		else:
			# new health_check effective_weight == origin_weight when all_dead
			if self.effective_weight == 0:
				self.effective_weight = self.origin_weight

		log.error(
			'real_server_enable_temporary|ip=%s,port=%s,effective_weight=%s',
			self.ip,
			self.port,
			self.effective_weight,
		)

	def change_weight(self, new_weight):
		if new_weight != 0:
			self.effective_weight = self.origin_weight
		else:
			self.effective_weight = new_weight
			self.up = False

	def change_health_status(self, up):
		self.up = up

	@classmethod
	def equal(cls, rs1, rs2):
		if (rs1.ip, rs1.port, rs1.vni) == (rs2.ip, rs2.port, rs2.vni):
			return True
		else:
			return False


class VirtualServer(object):
	VOID_QOS_NAME = 'unlimited'
	DEFAULT_UOA_VIP_SWITCH = 'off'
	DEFAULT_TOA_VIP_SWITCH = 'off'
	DEFAULT_TOA_SWITCH = 'on'
	DEFAULT_MSS = 1460
	DEFAULT_UOA_MODE = 0
	DEFAULT_UOA_TRAIL = 0
	DEFAULT_HASH_TRAGET = 'sip'
	DEFAULT_CONNECT_EXIT = 0
	DEFAULT_EIP = '0.0.0.0'
	def __init__(self, vip, port, protocol, scheduler, real_servers=None, master_node_lips=None, node_lips=None, master_inner_lips=None, inner_lips=None, master_outer_lips=None, outer_lips=None, target_vni=VNI.UNDERLAY_DEFAULT_VNI, is_deleted=False, qos_group_in=None, qos_group_out=None, qos_in=None, qos_out=None, uoa_vip_switch=None, toa_vip_switch=None, toa_switch=None, mss=None, uoa_mode=None, uoa_trail=None, scheduler_params=None, connect_exit=None, eip=None):

		self.vip = vip
		self.port = port
		self.protocol = protocol
		self.scheduler = scheduler
		if self.scheduler == 'conhash':
			self.scheduler_params = scheduler_params if scheduler_params else VirtualServer.DEFAULT_HASH_TRAGET
		else:
			self.scheduler_params = ''

		# Target vni means vni of VirtualServer.real_servers in overlay.
		# Since dpvs support both underlay and overlay rs,
		# the possible value of VirtualServer.real_servers.vni could be target_vni or -1
		self.target_vni = target_vni

		# According to https://www.jianshu.com/p/372bce982610
		# default parameters of different python object share same memory
		# so we cannot just assign default param to object field

		if real_servers is None:
			real_servers = []
		self.real_servers = real_servers

		if master_node_lips is None:
			master_node_lips = []
		self.master_node_lips = master_node_lips

		if node_lips is None:
			node_lips = []
		self.node_lips = node_lips

		if master_inner_lips is None:
			master_inner_lips = []
		self.master_inner_lips = master_inner_lips

		if inner_lips is None:
			inner_lips = []
		self.inner_lips = inner_lips

		if master_outer_lips is None:
			master_outer_lips = []
		self.master_outer_lips = master_outer_lips

		if outer_lips is None:
			outer_lips = []
		self.outer_lips = outer_lips

		self.blacklist = []
		self.whitelist = []
		self.is_deleted = is_deleted
		self.lock = Lock()
		self.qos_group_in = qos_group_in if qos_group_in else VirtualServer.VOID_QOS_NAME
		self.qos_group_out = qos_group_out if qos_group_out else VirtualServer.VOID_QOS_NAME
		self.qos_in = qos_in if qos_in else VirtualServer.VOID_QOS_NAME
		self.qos_out = qos_out if qos_out else VirtualServer.VOID_QOS_NAME
		self.uoa_vip_switch = uoa_vip_switch if uoa_vip_switch else VirtualServer.DEFAULT_UOA_VIP_SWITCH
		self.toa_vip_switch = toa_vip_switch if toa_vip_switch else VirtualServer.DEFAULT_TOA_VIP_SWITCH
		self.toa_switch = toa_switch if toa_switch else VirtualServer.DEFAULT_TOA_SWITCH
		self.mss = mss if mss else VirtualServer.DEFAULT_MSS
		self.uoa_mode = uoa_mode if uoa_mode else VirtualServer.DEFAULT_UOA_MODE
		self.uoa_trail = uoa_trail if uoa_trail else VirtualServer.DEFAULT_UOA_TRAIL
		self.connect_exit = connect_exit if connect_exit else VirtualServer.DEFAULT_CONNECT_EXIT
		self.eip = eip if eip else VirtualServer.DEFAULT_EIP

	def to_dict(self):
		return {
			'vip': self.vip,
			'port': self.port,
			'protocol': self.protocol,
			'scheduler': self.scheduler,
			'scheduler_params':self.scheduler_params,
			'real_servers': sorted([rs.to_dict() for rs in self.real_servers]),
			'master_node_lips': sorted(self.master_node_lips),
			'node_lips': sorted(self.node_lips),
			'master_inner_lips': sorted(self.master_inner_lips),
			'inner_lips': sorted(self.inner_lips),
			'master_outer_lips': sorted(self.master_outer_lips),
			'outer_lips': sorted(self.outer_lips),
			'blacklist': self.blacklist,
			'whitelist': self.whitelist,
			'uoa_trail': self.uoa_trail,
			'is_deleted': self.is_deleted,
			'qos_group_in': self.qos_group_in,
			'qos_group_out': self.qos_group_out,
			'qos_in': self.qos_in,
			'qos_out': self.qos_out,
			'uoa_vip_switch': self.uoa_vip_switch,
			'toa_vip_switch': self.toa_vip_switch,
			'toa_switch': self.toa_switch,
			'mss': self.mss,
			'uoa_mode': self.uoa_mode,
			'connect_exit': self.connect_exit,
			'eip': self.eip,
		}

	@classmethod
	def equal(cls, vs1, vs2):
		# 这里不用vip+port+protocol+vni判断的原因是在vpc0支持混布的场景下，可能无法通过ipvsadm来获得target_vni，后续支持internal vip时再来讨论适配
		if (vs1.vip, vs1.port, vs1.protocol) == (vs2.vip, vs2.port, vs2.protocol):
			return True
		else:
			return False


class VirtualServerFactory(object):

	CONFIG_FILE_PATH = '/etc/mesos-dpvs/services.json'
	_PREVIOUS_INSTANCE = None
	_PREVIOUS_CONTENT = None
	USE_EXPLICITLY_DELETE = False

	EXISTING_LIPS = set()
	NEW_LIPS = set()

	@classmethod
	def load(cls):
		node_lip_changed = get_config().NODE_LIP_CHANGED
		content = read_file(cls.CONFIG_FILE_PATH)
		if not content:
			log.error('%s does not exist or empty' % cls.CONFIG_FILE_PATH)
			return []
		if (content == cls._PREVIOUS_CONTENT) and (not node_lip_changed):
			return cls._PREVIOUS_INSTANCE

		config = json.loads(content)
		virtual_servers = []

		previous_rs_map = {}
		if cls._PREVIOUS_INSTANCE is not None:
			for vs in cls._PREVIOUS_INSTANCE:
				for rs in vs.real_servers:
					key = (vs.vip, vs.port, vs.protocol, vs.scheduler, rs.ip, rs.port, rs.vni)
					previous_rs_map[key] = rs

		tmp_new_vtep_list = set()
		_non_advertisable_ips = set()

		master_node_lips = get_config().master_node_lips
		node_lips = get_config().node_lips

		for vs_config in config:
			if vs_config.has_key('is_deleted'):
				VirtualServerFactory.USE_EXPLICITLY_DELETE = True

			vs_is_deleted = vs_config.get('is_deleted', False)
			qos_group_in = vs_config.get('qos_group_in', None)
			qos_group_out = vs_config.get('qos_group_out', None)
			qos_in = vs_config.get('qos_in', None)
			qos_out = vs_config.get('qos_out', None)
			uoa_vip_switch = vs_config.get('uoa_vip_switch', VirtualServer.DEFAULT_UOA_VIP_SWITCH)
			toa_vip_switch = vs_config.get('toa_vip_switch', VirtualServer.DEFAULT_TOA_VIP_SWITCH)
			toa_switch = vs_config.get('toa_switch', VirtualServer.DEFAULT_TOA_SWITCH)
			mss = vs_config.get('mss', VirtualServer.DEFAULT_MSS)
			uoa_mode = vs_config.get('uoa_mode', VirtualServer.DEFAULT_UOA_MODE)
			scheduler_params = vs_config.get('scheduler_params', VirtualServer.DEFAULT_HASH_TRAGET) if vs_config['scheduler'] == 'conhash' else ''
			connect_exit = vs_config.get('connect_exit', VirtualServer.DEFAULT_CONNECT_EXIT)
			eip = vs_config.get('eip', VirtualServer.DEFAULT_EIP)

			vs = VirtualServer(
				vs_config['vip'],
				vs_config['port'],
				vs_config['protocol'],
				vs_config['scheduler'],
				master_node_lips=master_node_lips,
				node_lips=node_lips,
				master_outer_lips=vs_config['master_outer_lips'],
				outer_lips=vs_config['outer_lips'],
				master_inner_lips=vs_config['master_inner_lips'],
				inner_lips=vs_config['inner_lips'],
				target_vni=str(vs_config['target_vni']),
				is_deleted=vs_is_deleted,
				qos_group_in=qos_group_in,
				qos_group_out=qos_group_out,
				qos_in=qos_in,
				qos_out=qos_out,
				uoa_vip_switch=uoa_vip_switch,
				toa_vip_switch=toa_vip_switch,
				toa_switch=toa_switch,
				mss=mss,
				uoa_mode=uoa_mode,
				scheduler_params=scheduler_params,
				connect_exit=connect_exit,
				eip=eip
			)

			if vs_is_deleted:
				virtual_servers.append(vs)
				continue

			for rs_config in vs_config['real_servers']:
				rs = RealServer(
					rs_config['ip'],
					rs_config['port'],
					origin_weight=rs_config['weight'],
					effective_weight=rs_config['weight'],
					vni=rs_config['vni'],
				)

				# Reuse exist real servers to avoid success count and fail count miss.
				key = (vs.vip, vs.port, vs.protocol, vs.scheduler, rs.ip, rs.port, rs.vni)
				previous_rs = previous_rs_map.get(key)
				if previous_rs is not None:
					# And only change the effective_weight of the previous rs when its effective_weight didn't changed
					# by health check.
					if previous_rs.origin_weight == previous_rs.effective_weight:
						previous_rs.effective_weight = rs.effective_weight
					previous_rs.origin_weight = rs.origin_weight
					rs = previous_rs

				vs.real_servers.append(rs)

				if rs.vni != VNI.UNDERLAY_DEFAULT_VNI:
					tmp_new_vtep_list.add(Vtep(rs.vni, rs.ip, node_ip=rs_config['node_ip']))

			vs.blacklist = vs_config.get('blacklist', [])
			vs.whitelist = vs_config.get('whitelist', [])
			vs.uoa_trail = vs_config.get('uoa_trail', 0)

			# del these ips from bgp list
			if not vs_config.get('can_advertise_vip', True):
				_non_advertisable_ips.add(vs_config['vip'])
				_non_advertisable_ips.update(vs_config['outer_lips'])

			virtual_servers.append(vs)

		cls._PREVIOUS_INSTANCE = virtual_servers
		cls._PREVIOUS_CONTENT = content
		VtepFactory.new_vtep_set = tmp_new_vtep_list
		Bird.non_advertisable_ips = _non_advertisable_ips

		return virtual_servers

	@classmethod
	def equals(cls, new_virtual_servers, old_virtual_servers):
		if new_virtual_servers is None and old_virtual_servers is not None:
			return False
		if new_virtual_servers is not None and old_virtual_servers is None:
			return False

		if new_virtual_servers is None and old_virtual_servers is None:
			return True

		new_virtual_servers_json = json.dumps(
			sorted([vs.to_dict() for vs in new_virtual_servers]),
			sort_keys=True,
		)
		old_virtual_servers_json = json.dumps(
			sorted([vs.to_dict() for vs in old_virtual_servers]),
			sort_keys=True,
		)

		return new_virtual_servers_json == old_virtual_servers_json


class SnatServer(object):

	def __init__(self, protocol, wan_ips=None):
		self.protocol = protocol
		if wan_ips is None:
			wan_ips = []
		self.wan_ips = wan_ips

	def to_dict(self):
		return {
			'protocol': self.protocol,
			'wan_ips': self.wan_ips,
		}


class SnatServerFactory(object):

	CONFIG_FILE_PATH = '/etc/mesos-dpvs/snat_wan_ips.json'
	_PREVIOUS_INSTANCE = []
	_PREVIOUS_CONTENT = None

	@classmethod
	def load(cls):
		content = read_file(cls.CONFIG_FILE_PATH)

		if content == cls._PREVIOUS_CONTENT:
			return cls._PREVIOUS_INSTANCE

		snat_servers = []
		if content is not None:
			config = json.loads(content)

			for protocol in ['tcp', 'udp', 'icmp']:
				ss = SnatServer(
					protocol=protocol,
					wan_ips=config,
				)
				snat_servers.append(ss)

		cls._PREVIOUS_INSTANCE = snat_servers
		cls._PREVIOUS_CONTENT = content

		return snat_servers


class IPVSAdminHelper(object):

	MISSING_VS_PATH = '/etc/mesos-dpvs/missing_services.json'
	MISSING_VTEP = set()

	@classmethod
	def get_snat_servers(cls):
		vs_list = get_command_output_with_lock('ipvsadm -Ln')
		if vs_list == ERROR_RES:
			return None
		output = vs_list.split('\n')
		# Match 'MATCH icmp,oif=dpdk2 rr'
		snat_server_pattern = re.compile(r'MATCH\s+(?P<protocol>\w+),(.*?)oif=(?P<nic>\w+)\s+rr')
		# Match '  -> 10.62.120.2:80               FullNat 100    0          0'
		wan_ip_pattern = re.compile(r'^\s+->\s+(?P<ip>[\d.]+):0\s+SNAT\s+(?P<weight>\d+)\s+.*')

		snat_servers = []
		for line in output:
			match = snat_server_pattern.match(line)
			if match:
				snat_servers.append(
					SnatServer(
						protocol=match.group('protocol').lower(),
					)
				)
				continue

			match = wan_ip_pattern.match(line)
			if match:
				snat_servers[-1].wan_ips.append(match.group('ip'))
				continue

		return snat_servers

	@classmethod
	def update_snat_servers(cls, snat_servers, wan_nic, src_range, current_snat_servers):
		# Update local IPs for snat servers.
		for new_ss in snat_servers:
			found_ss = None

			# Match exist snat server.
			for current_ss in current_snat_servers:
				if current_ss.protocol == new_ss.protocol:
					found_ss = current_ss
					break

			if found_ss is None:
				execute('ipvsadm -A -s rr -H proto=%s,oif=%s,src-range=%s' % (new_ss.protocol, wan_nic, src_range))
				found_ss = SnatServer(
					protocol=new_ss.protocol,
				)
				current_snat_servers.append(found_ss)

			for wan_ip in set(found_ss.wan_ips).difference(set(new_ss.wan_ips)):
				# Clear expire wan_ip.
				execute('ipvsadm -d -H proto=%s,oif=%s,src-range=%s -r %s:0' % (
					new_ss.protocol,
					wan_nic,
					src_range,
					wan_ip,
				))

			for wan_ip in set(new_ss.wan_ips).difference(set(found_ss.wan_ips)):
				DPIPHelper.add_ip(wan_nic, ip_with_mask=IPWithMask(ip=wan_ip, option='sapool'))
				# Add missing wan_ip.
				execute('ipvsadm -a -H proto=%s,oif=%s,src-range=%s -r %s:0 -w 100 -J' % (
					new_ss.protocol,
					wan_nic,
					src_range,
					wan_ip,
				))

		# Clear expire snat servers.
		for current_ss in current_snat_servers:
			found_ss = None

			for new_ss in snat_servers:
				if current_ss.protocol == new_ss.protocol:
					found_ss = current_ss
					break

			if found_ss is None:
				execute('ipvsadm -D -H proto=%s,oif=%s,src-range=%s' % (current_ss.protocol, wan_nic, src_range))

	@classmethod
	def get_virtual_servers(cls):
		vs_list = get_command_output_with_lock('ipvsadm -Ln')

		if vs_list == ERROR_RES:
			return None

		output = vs_list.split('\n')
		# Match 'TCP  103.223.1.74:80 wrr'
		virtual_server_pattern = re.compile(
			r'^(?P<protocol>TCP|UDP|ICMP)\s+(?P<vip>[\d.]+):(?P<port>\d+)\s+(?P<scheduler>\w+)(?:\s+(?P<scheduler_params>\w+))?')
		# Match '  -> 10.62.120.2:80               FullNat 100    0          0'
		# Or '-> vni=0,44.2.2.2:https               FullNat 1      0          0'
		real_server_pattern = re.compile(r'^\s+->\s+(vni=(?P<vni>[\d.]+),)?(?P<ip>[\d.]+):(?P<port>\d+)\s+FullNat\s+(?P<weight>\d+)\s+.*')

		existing_virtual_servers = []
		for line in output:
			match = virtual_server_pattern.match(line)
			if match:
				existing_virtual_servers.append(
					VirtualServer(
						vip=match.group('vip'),
						port=int(match.group('port')),
						protocol=match.group('protocol').lower(),
						scheduler=match.group('scheduler'),
						scheduler_params=match.group('scheduler_params') if match.group('scheduler_params') else ''
					)
				)
				continue

			match = real_server_pattern.match(line)
			if match:
				_vni = match.group('vni')
				if not _vni:
					# underlay doesn't have vni info
					_vni = VNI.UNDERLAY_DEFAULT_VNI

				existing_virtual_servers[-1].real_servers.append(
					RealServer(
						ip=match.group('ip'),
						port=int(match.group('port')),
						origin_weight=int(match.group('weight')),
						effective_weight=int(match.group('weight')),
						vni=_vni
					)
				)
				continue

		# sync node_lips
		IPVSAdminHelper.sync_existing_lips('node_lips', existing_virtual_servers)
		# sync inner lips
		IPVSAdminHelper.sync_existing_lips('inner_lips', existing_virtual_servers)
		# sync outer lips
		IPVSAdminHelper.sync_existing_lips('outer_lips', existing_virtual_servers)

		# fill ACL
		acl_match_pattern = re.compile(r'(?P<vip>[\d\.]+):(?P<port>\d+)\s+(?P<protocol>TCP|UDP|ICMP)\s+(?P<cidr>[\d\./]+)')

		output = get_command_output_with_lock('ipvsadm --get-blklst').split('\n')
		# Match 192.168.0.10:58000    TCP      10.129.98.0/24
		for line in output:
			match = acl_match_pattern.match(line)
			if match:
				vip = match.group('vip')
				port = int(match.group('port'))
				protocol = match.group('protocol').lower()
				cidr = match.group('cidr')
				for virtual_server in existing_virtual_servers:
					if virtual_server.vip == vip and \
						virtual_server.port == port and \
						virtual_server.protocol == protocol:
						virtual_server.blacklist.append(cidr)

		output = get_command_output_with_lock('ipvsadm --get-whtlst').split('\n')
		for line in output:
			match = acl_match_pattern.match(line)
			if match:
				vip = match.group('vip')
				port = int(match.group('port'))
				protocol = match.group('protocol').lower()
				cidr = match.group('cidr')
				for virtual_server in existing_virtual_servers:
					if virtual_server.vip == vip and \
						virtual_server.port == port and \
						virtual_server.protocol == protocol:
						virtual_server.whitelist.append(cidr)

		# fill vs conf
		# Match UDP  100.64.12.101:56 wrr uoa-trail 0 uoa-mode opp opt-vip off qos-group-in-bytes 100.64.12.101-in-bytes qos-group-out-bytes 100.64.12.101-out-bytes
		vs_conf_pattern = re.compile(r'^(?P<protocol>TCP|UDP|ICMP)\s+(?P<vip>[\d.]+):(?P<port>\d+)\s+(?P<scheduler>\w+).*')

		result = get_command_output_with_lock('ipvsadm -ln --verbose')
		if result == ERROR_RES:
			return existing_virtual_servers

		def get_uoa_trail():
			uoa_pattern = re.compile(r'.*uoa-trail\s+(?P<uoa_trail>\d+).*')
			match_uoa = uoa_pattern.match(line)
			if match_uoa:
				return int(match_uoa.group('uoa_trail'))
			else:
				return 0

		def get_qos(regular):
			qos_pattern = re.compile(r'.*%s (?P<qos>\S+).*' % regular)
			match_qos = qos_pattern.match(line)
			if match_qos:
				return match_qos.group('qos')
			else:
				return VirtualServer.VOID_QOS_NAME

		def get_uoa_vip_switch():
			uoa_pattern = re.compile(r'.*UDP.*uoa-trail\s+(?P<uoa_trail>\d+).*opt-vip\s+(?P<uoa_vip_switch>\S+).*')
			match_uoa = uoa_pattern.match(line)
			if match_uoa:
				return match_uoa.group('uoa_vip_switch')
			else:
				return VirtualServer.DEFAULT_UOA_VIP_SWITCH

		def get_toa_vip_switch():
			toa_vip_switch_pattern = re.compile(r'.*TCP.*opt-vip\s+(?P<toa_vip_switch>\S+).*')
			match_toa = toa_vip_switch_pattern.match(line)
			if match_toa:
				return match_toa.group('toa_vip_switch')
			else:
				return VirtualServer.DEFAULT_TOA_VIP_SWITCH

		def get_connect_exit():
			connect_exit_pattern = re.compile(r'.* exit (?P<exit>\d+).*')
			match_connect_exit = connect_exit_pattern.match(line)
			if match_connect_exit:
				return int(match_connect_exit.group('exit'))
			else:
				return VirtualServer.DEFAULT_CONNECT_EXIT

		def get_eip():
			eip_pattern = re.compile(r'.* eip (?P<eip>\S+).*')
			match_eip = eip_pattern.match(line)
			if match_eip:
				return match_eip.group('eip')
			else:
				return VirtualServer.DEFAULT_EIP

		def get_toa_switch():
			toa_switch_pattern = re.compile(r'.*TCP.*toa\s+(?P<toa_switch>\S+).*')
			match_toa = toa_switch_pattern.match(line)
			if match_toa:
				return match_toa.group('toa_switch')
			else:
				return VirtualServer.DEFAULT_TOA_SWITCH

		def get_mss():
			mss_pattern = re.compile(r'.*TCP.* mss (?P<mss>\d+).*')
			match_mss = mss_pattern.match(line)
			if match_mss:
				return int(match_mss.group('mss'))
			else:
				return VirtualServer.DEFAULT_MSS

		def get_uoa_mode():
			uoa_pattern = re.compile(r'.*uoa-mode\s+(?P<uoa_mode>\S+).*')
			match_uoa = uoa_pattern.match(line)
			if match_uoa:
				if match_uoa.group('uoa_mode') == 'opp':
					return 0
				elif match_uoa.group('uoa_mode') == 'ipo':
					return 1
				elif match_uoa.group('uoa_mode') == 'upo':
					return 2
			else:
				return VirtualServer.DEFAULT_UOA_MODE

		output = result.split('\n')
		for line in output:
			match_vs = vs_conf_pattern.match(line)
			if match_vs:
				vip = match_vs.group('vip')
				port = int(match_vs.group('port'))
				protocol = match_vs.group('protocol').lower()
				for virtual_server in existing_virtual_servers:
					if (virtual_server.vip, virtual_server.port, virtual_server.protocol) == (vip, port, protocol):
						virtual_server.uoa_trail = get_uoa_trail()
						virtual_server.qos_group_in = get_qos('qos-group-in-bytes')
						virtual_server.qos_group_out = get_qos('qos-group-out-bytes')
						virtual_server.qos_in = get_qos('qos-in-bytes')
						virtual_server.qos_out = get_qos('qos-out-bytes')
						virtual_server.uoa_vip_switch = get_uoa_vip_switch()
						virtual_server.toa_vip_switch = get_toa_vip_switch()
						virtual_server.toa_switch = get_toa_switch()
						virtual_server.mss = get_mss()
						virtual_server.uoa_mode = get_uoa_mode()
						virtual_server.connect_exit = get_connect_exit()
						virtual_server.eip = get_eip()

		return existing_virtual_servers

	@classmethod
	def sync_existing_lips(cls, lip_type, virtual_servers):

		if lip_type == 'inner_lips':
			list_lip_cmd = 'ipvsadm --get-inner-laddr'
			lip_field = 'inner_lips'
			master_lip_field = 'master_inner_lips'
		elif lip_type == 'outer_lips':
			list_lip_cmd = 'ipvsadm --get-outer-laddr'
			lip_field = 'outer_lips'
			master_lip_field = 'master_outer_lips'
		elif lip_type == 'node_lips':
			list_lip_cmd = 'ipvsadm -G'
			lip_field = 'node_lips'
			master_lip_field = 'master_node_lips'
		else:
			log.error('unsupported lip type when syncing lips: %s' % lip_type)
			exit(-1)

		# get inner lip
		output = get_command_output_with_lock(list_lip_cmd).split('\n')
		# Match '143.92.64.130:53     1        TCP'
		virtual_server_pattern = re.compile(r'^(?P<vip>[\d.]+):(?P<port>\d+)\s+\d+\s+(?P<protocol>TCP|UDP|ICMP)')
		# Match '                              10.62.120.96         0          0'
		lip_pattern = re.compile(r'^\s+(vni=(?P<vni>\d+),)?(?P<lip>[\d.]+)\s+')
		# Match '                              10.62.120.96         0          0  [backup]'
		slave_lip_pattern = re.compile(r'^\s+(vni=(?P<vni>\d+),)?(?P<lip>[\d.]+).*[backup]')

		existing_virtual_server = None
		for line in output:
			match = virtual_server_pattern.match(line)
			if match:
				vip = match.group('vip')
				port = int(match.group('port'))
				protocol = match.group('protocol').lower()
				for virtual_server in virtual_servers:
					if virtual_server.vip == vip and \
						virtual_server.port == port and \
						virtual_server.protocol == protocol:
						existing_virtual_server = virtual_server

				continue

			match = lip_pattern.match(line)
			if match:
				lip = match.group('lip')
				getattr(existing_virtual_server, lip_field).append(lip)

				vni = match.group('vni')
				if vni != None:
					existing_virtual_server.target_vni = vni

				match = slave_lip_pattern.match(line)
				if not match:
					getattr(existing_virtual_server, master_lip_field).append(lip)

	# 为了简化逻辑，新的vip和lip列表在这个函数里初始化，不要提前返回/吞异常
	@classmethod
	def update_virtual_servers(cls, new_virtual_servers, nics, config, existing_virtual_servers=None):
		# fail to get dpvs vs list
		if existing_virtual_servers is None:
			log.error('fail to get fullnat vs list')
			return None

		if len(new_virtual_servers) == 0 and len(existing_virtual_servers) != 0:
			log.error('empty vs list in %s, shopee-mesos-dpvs quiting' % VirtualServerFactory.CONFIG_FILE_PATH)
			cls.report_missing_virtual_servers(existing_virtual_servers)
			exit(-1)

		missing_virtual_servers = []

		new_vs_rs_map = {}
		for vs in new_virtual_servers:
			if vs.is_deleted:
				continue
			for rs in vs.real_servers:
				key = (vs.vip, vs.port, vs.protocol, rs.ip, rs.port, rs.vni)
				new_vs_rs_map[key] = rs

		# save existing VIP list
		tmp_virtual_servers = []

		# Clear expire virtual servers.
		for existing_vs in existing_virtual_servers:  # loop over existing virtual servers
			new_vs = None

			# find this existing vs in the new vs list
			for _new_vs in new_virtual_servers:
				if VirtualServer.equal(existing_vs, _new_vs):
					new_vs = _new_vs
					break

			if VirtualServerFactory.USE_EXPLICITLY_DELETE:
				if new_vs is None:
					log.error('existing vs %s missing in %s' % (existing_vs.to_dict(), VirtualServerFactory.CONFIG_FILE_PATH))
					missing_virtual_servers.append(existing_vs)
					tmp_virtual_servers.append(existing_vs)
					continue
				elif new_vs.is_deleted:
					# existing vs not found in the new vs list, delete it
					IPVSAdminHelper.del_vs(existing_vs)
					existing_vs.real_servers = []
					continue
				else:
					tmp_virtual_servers.append(existing_vs)
			else:
				if new_vs is None:
					# existing vs not found in the new vs list, delete it
					IPVSAdminHelper.del_vs(existing_vs)
					existing_vs.real_servers = []
					continue
				else:
					tmp_virtual_servers.append(existing_vs)

			# Clear expire real servers.
			tmp_real_servers = []
			has_rs_deleted = False
			for existing_rs in existing_vs.real_servers:
				matched_rs = None

				# can we find this existing rs in the new rs list?
				for new_rs in new_vs.real_servers:
					if RealServer.equal(existing_rs, new_rs):
						matched_rs = new_rs
						break

				if matched_rs is None:
					# existing rs not found in the new rs list, delete it
					IPVSAdminHelper.del_rs(existing_vs, existing_rs)
					has_rs_deleted = True
				else:
					tmp_real_servers.append(existing_rs)

			if not GetMesosHCMod.IS_MESOS_WITH_HC and has_rs_deleted:
				# 删除时：半死不活到全死权重变更
				IPVSAdminHelper.update_dead_weight(existing_vs, tmp_real_servers, new_vs_rs_map, False)

			existing_vs.real_servers = tmp_real_servers

		existing_virtual_servers = tmp_virtual_servers
		cls.report_missing_virtual_servers(missing_virtual_servers)

		# Add or update virtual servers.
		for new_vs in new_virtual_servers:
			if new_vs.is_deleted:
				continue
			matched_vs = None

			# Match exist virtual server.
			for existing_vs in existing_virtual_servers:
				if VirtualServer.equal(existing_vs, new_vs):
					matched_vs = existing_vs
					break

			if matched_vs and (matched_vs.scheduler != new_vs.scheduler or matched_vs.scheduler_params != new_vs.scheduler_params):
				# Update if scheduler is different.
				IPVSAdminHelper.set_vs_scheduler(new_vs)
				matched_vs.scheduler = new_vs.scheduler
				matched_vs.scheduler_params = new_vs.scheduler_params
			elif matched_vs is None:
				IPVSAdminHelper.add_vs(new_vs)
				matched_vs = VirtualServer(
					vip=new_vs.vip,
					port=new_vs.port,
					protocol=new_vs.protocol,
					scheduler=new_vs.scheduler,
					target_vni=new_vs.target_vni,
					qos_group_in=new_vs.qos_group_in,
					qos_group_out=new_vs.qos_group_out,
					qos_in=new_vs.qos_in,
					qos_out=new_vs.qos_out,
					uoa_vip_switch=new_vs.uoa_vip_switch,
					toa_vip_switch=new_vs.toa_vip_switch,
					toa_switch=new_vs.toa_switch,
					mss=new_vs.mss,
					uoa_mode=new_vs.uoa_mode,
					uoa_trail=new_vs.uoa_trail,
					scheduler_params=new_vs.scheduler_params,
					connect_exit=new_vs.connect_exit,
					eip=new_vs.eip,
				)
				existing_virtual_servers.append(matched_vs)

			has_rs_upsert = False
			for new_rs in new_vs.real_servers:
				matched_rs = None

				# Match exist real server.
				for existing_rs in matched_vs.real_servers:
					if RealServer.equal(existing_rs, new_rs):
						matched_rs = existing_rs
						break

				if matched_rs and \
						(new_rs.effective_weight != matched_rs.effective_weight or new_rs.origin_weight != matched_rs.origin_weight):
					matched_rs.effective_weight = new_rs.effective_weight
					matched_rs.origin_weight = new_rs.origin_weight
					matched_rs.up = new_rs.up
					IPVSAdminHelper.set_rs_weight(new_vs, new_rs)
					has_rs_upsert = True

				elif matched_rs is None:
					matched_rs = RealServer(
						ip=new_rs.ip,
						port=new_rs.port,
						origin_weight=new_rs.origin_weight,
						effective_weight=new_rs.origin_weight,
						vni=new_rs.vni,
					)
					has_rs_upsert = True
					IPVSAdminHelper.add_rs(new_vs, matched_rs)
					matched_vs.real_servers.append(matched_rs)

			if not GetMesosHCMod.IS_MESOS_WITH_HC and has_rs_upsert:
				# 添加/更新时：半死不活到全死，全死到半死不活权重变更
				IPVSAdminHelper.update_dead_weight(matched_vs, matched_vs.real_servers, new_vs_rs_map, True)

		# 将需要更新的新老vs下标对齐，避免重复匹配
		sorted_existing_vs = []
		sorted_new_vs = []
		acl_cmds = []
		for new_vs in new_virtual_servers:
			if new_vs.is_deleted:
				continue
			matched_vs = None

			# Match exist virtual server.
			for existing_vs in existing_virtual_servers:
				if VirtualServer.equal(existing_vs, new_vs):
					matched_vs = existing_vs
					break

			if matched_vs is None:
				continue
			sorted_existing_vs.append(matched_vs)
			sorted_new_vs.append(new_vs)

		for i in range(len(sorted_existing_vs)):
			matched_vs = sorted_existing_vs[i]
			new_vs = sorted_new_vs[i]
			# Update local IPs for virtual servers.
			IPVSAdminHelper.update_lip(matched_vs, new_vs, 'node_lips', config.cluster_type, config.lan_nic)
			reset_node_config_change_flags()
			IPVSAdminHelper.update_lip(matched_vs, new_vs, 'outer_lips', config.cluster_type, config.lan_nic)
			IPVSAdminHelper.update_lip(matched_vs, new_vs, 'inner_lips', config.cluster_type, config.lan_nic)

			acl_cmds += IPVSAdminHelper.gather_vs_acl_cmd(matched_vs, new_vs)

			# Update qos parameters
			if new_vs.qos_group_in != matched_vs.qos_group_in or \
				new_vs.qos_group_out != matched_vs.qos_group_out or \
				new_vs.qos_in != matched_vs.qos_in or \
				new_vs.qos_out != matched_vs.qos_out:
					IPVSAdminHelper.update_qos(new_vs)
					matched_vs.qos_group_in = new_vs.qos_group_in
					matched_vs.qos_group_out = new_vs.qos_group_out
					matched_vs.qos_in = new_vs.qos_in
					matched_vs.qos_out = new_vs.qos_out

			if new_vs.protocol == 'udp':
				# Update uoa_trail
				if new_vs.uoa_trail != matched_vs.uoa_trail:
					if IPVSAdminHelper.update_uoa_trail(new_vs.uoa_trail, new_vs) != ERROR_RES:
						matched_vs.uoa_trail = new_vs.uoa_trail

				# Update uoa_vip_switch
				if new_vs.uoa_vip_switch != matched_vs.uoa_vip_switch:
					if IPVSAdminHelper.update_uoa_vip_switch(new_vs.uoa_vip_switch, new_vs) != ERROR_RES:
						matched_vs.uoa_vip_switch = new_vs.uoa_vip_switch
				# Update uoa_mode
				if new_vs.uoa_mode != matched_vs.uoa_mode:
					if IPVSAdminHelper.update_uoa_mode(new_vs.uoa_mode, new_vs) != ERROR_RES:
						matched_vs.uoa_mode = new_vs.uoa_mode

			if new_vs.protocol == 'tcp':
				# Update toa_switch
				if new_vs.toa_switch != matched_vs.toa_switch:
					if IPVSAdminHelper.update_toa_switch(new_vs.toa_switch, new_vs) != ERROR_RES:
						matched_vs.toa_switch = new_vs.toa_switch

				# Update toa_vip_switch
				if new_vs.toa_vip_switch != matched_vs.toa_vip_switch:
					if IPVSAdminHelper.update_toa_vip_switch(new_vs.toa_vip_switch, new_vs) != ERROR_RES:
						matched_vs.toa_vip_switch = new_vs.toa_vip_switch

				# Update mss
				if new_vs.mss != matched_vs.mss:
					if IPVSAdminHelper.update_mss(new_vs.mss, new_vs) != ERROR_RES:
						matched_vs.mss = new_vs.mss

			if new_vs.connect_exit != matched_vs.connect_exit:
				if IPVSAdminHelper.update_connect_exit(new_vs.connect_exit, new_vs) != ERROR_RES:
					matched_vs.connect_exit = new_vs.connect_exit

			if new_vs.eip != matched_vs.eip:
				if IPVSAdminHelper.update_eip(new_vs.eip, new_vs) != ERROR_RES:
					matched_vs.eip = new_vs.eip
		IPVSAdminHelper.batch_update_acl(acl_cmds)
		for i in range(len(sorted_existing_vs)):
			matched_vs = sorted_existing_vs[i]
			new_vs = sorted_new_vs[i]
			matched_vs.blacklist = new_vs.blacklist
			matched_vs.whitelist = new_vs.whitelist

		# Update VIPs and lips.
		new_vips = set()
		new_bgp_master_lips = set()   # master_node_lip + master_outer_lip
		new_bgp_lips = set()          # node_lip + outer_lip
		new_lips = set()              # node_lip + outer_lip + inner_lip
		missing_vtep = set()
		missing_qos = set()
		new_dpip_addrs = set()

		for misssing_vs in missing_virtual_servers:
			new_vips.add(misssing_vs.vip)
			new_bgp_master_lips.update(misssing_vs.master_node_lips)
			new_bgp_lips.update(misssing_vs.node_lips)
			new_bgp_master_lips.update(misssing_vs.master_outer_lips)
			new_bgp_lips.update(misssing_vs.outer_lips)
			new_lips.update(IPVSAdminHelper.get_vs_lips(misssing_vs))
			for rs in misssing_vs.real_servers:
				if rs.vni != VNI.UNDERLAY_DEFAULT_VNI:
					missing_vtep.add("%s,%s" % (rs.vni, rs.ip))
			missing_qos.add(misssing_vs.qos_group_in)
			missing_qos.add(misssing_vs.qos_group_out)
			missing_qos.add(misssing_vs.qos_in)
			missing_qos.add(misssing_vs.qos_out)

			new_dpip_addrs.update(IPWithMask.cast_from_ips(misssing_vs.inner_lips, vni=misssing_vs.target_vni, ignore_del_err=True))
			new_dpip_addrs.update(IPWithMask.cast_from_ips(misssing_vs.node_lips + misssing_vs.outer_lips, ignore_del_err=True))
			new_dpip_addrs.add(IPWithMask(misssing_vs.vip))

		IPVSAdminHelper.MISSING_VTEP = missing_vtep
		PalShellHelper.MISSING_QOS_NAMES = missing_qos

		for new_vs in new_virtual_servers:
			if new_vs.is_deleted:
				continue

			new_vips.add(new_vs.vip)

			new_bgp_master_lips.update(new_vs.master_node_lips)
			new_bgp_lips.update(new_vs.node_lips)
			new_bgp_master_lips.update(new_vs.master_outer_lips)
			new_bgp_lips.update(new_vs.outer_lips)
			new_lips.update(IPVSAdminHelper.get_vs_lips(new_vs))

			new_dpip_addrs.update(IPWithMask.cast_from_ips(new_vs.inner_lips, vni=new_vs.target_vni, ignore_del_err=True))
			new_dpip_addrs.update(IPWithMask.cast_from_ips(new_vs.node_lips + new_vs.outer_lips, ignore_del_err=True))
			new_dpip_addrs.add(IPWithMask(new_vs.vip))

		# vtep changed only when vs list changed
		PalShellHelper.update_vtep()

		config.set_vips(new_vips)
		config.set_master_lips(new_bgp_master_lips)
		config.set_lips(new_bgp_lips)
		VirtualServerFactory.NEW_LIPS = new_lips

		new_dpip_addrs.add(IPWithMask(config.lan_inner_ip, config.lan_mask, option='sapool fdir_only'))
		if FullnatConfig.HAS_WAN_NIC:
			new_dpip_addrs.add(IPWithMask(config.wan_inner_ip, config.wan_mask))
		DPIPHelper.new_addr_set = new_dpip_addrs

		return existing_virtual_servers

	@classmethod
	def update_dead_weight(cls, virtual_server, real_servers, new_vs_rs_map, is_add):
		is_all_dead = True
		for rs in real_servers:
			key = (virtual_server.vip, virtual_server.port, virtual_server.protocol, rs.ip, rs.port, rs.vni)
			if new_vs_rs_map[key] and new_vs_rs_map[key].up and rs.effective_weight > 0:
				is_all_dead = False
		if is_all_dead:
			for rs in real_servers:
				key = (virtual_server.vip, virtual_server.port, virtual_server.protocol, rs.ip, rs.port, rs.vni)
				if new_vs_rs_map[key] and new_vs_rs_map[key].origin_weight > 0 and not new_vs_rs_map[key].up and rs.effective_weight == 0:
					rs.origin_weight = new_vs_rs_map[key].origin_weight
					rs.effective_weight = new_vs_rs_map[key].origin_weight
					rs.up = False
					new_vs_rs_map[key].effective_weight = new_vs_rs_map[key].origin_weight
					IPVSAdminHelper.set_rs_weight(virtual_server, rs)
		elif is_add:
			for rs in real_servers:
				key = (virtual_server.vip, virtual_server.port, virtual_server.protocol, rs.ip, rs.port, rs.vni)
				if new_vs_rs_map[key] and not new_vs_rs_map[key].up and rs.effective_weight > 0:
					rs.origin_weight = new_vs_rs_map[key].origin_weight
					rs.effective_weight = 0
					new_vs_rs_map[key].effective_weight = 0
					rs.up = False
					IPVSAdminHelper.set_rs_weight(virtual_server, rs)

	@classmethod
	def add_vs(cls, vs):
		uoa_conf = ''
		qos_conf = ''
		vip_switch_conf = ''
		toa_switch = ''
		mss_conf = ''
		connect_exit = ''
		eip = ''
		scheduler_conf = vs.scheduler
		if PalShellHelper.ENABLE_QOS_UPDATE:
			if vs.qos_group_in != VirtualServer.VOID_QOS_NAME:
				qos_conf += '--qos-group-in-bytes %s ' % vs.qos_group_in
			if vs.qos_group_out != VirtualServer.VOID_QOS_NAME:
				qos_conf += '--qos-group-out-bytes %s ' % vs.qos_group_out
			if vs.qos_in != VirtualServer.VOID_QOS_NAME:
				qos_conf += '--qos-in-bytes %s ' % vs.qos_in
			if vs.qos_out != VirtualServer.VOID_QOS_NAME:
				qos_conf += '--qos-out-bytes %s ' % vs.qos_out
		if vs.protocol == 'udp':
			if vs.uoa_mode == 2:
				uoa_mode = 'upo'
			elif vs.uoa_mode == 1:
				uoa_mode = 'ipo'
			else:
				uoa_mode = 'opp'
			uoa_conf = '--uoa trail=%s,mode=%s' % (vs.uoa_trail,uoa_mode)
			if PalShellHelper.ENABLE_UOA_VIP_SWITCH:
				vip_switch_conf = '--opt-vip %s' % vs.uoa_vip_switch
		if vs.protocol == 'tcp':
			if PalShellHelper.ENABLE_TOA_SWITCH:
				toa_switch = '--toa %s' % vs.toa_switch
			if PalShellHelper.ENABLE_TOA_VIP_SWITCH:
				vip_switch_conf = '--opt-vip %s' % vs.toa_vip_switch
			if PalShellHelper.ENABLE_MSS:
				mss_conf = '--mss %s' % vs.mss
		if vs.scheduler == 'conhash':
			scheduler_conf = '%s --hash-target %s' % (scheduler_conf, vs.scheduler_params)
		if vs.connect_exit != 0 and PalShellHelper.ENABLE_CONNECT_EXIT:
			connect_exit = '--exit %s' % vs.connect_exit
		if vs.eip != VirtualServer.DEFAULT_EIP and PalShellHelper.ENABLE_EIP:
			eip = '--eip %s' % vs.eip
		execute('ipvsadm -A --%s-service %s:%s -s %s %s %s %s %s %s %s %s' % (
				vs.protocol, vs.vip, vs.port, scheduler_conf, uoa_conf, qos_conf, toa_switch, vip_switch_conf, mss_conf, connect_exit, eip))

	@classmethod
	def del_vs(cls, real_server):
		execute('ipvsadm -D --%s-service %s:%s' % (real_server.protocol, real_server.vip, real_server.port))

	@classmethod
	def set_vs_scheduler(cls, virtual_server):
		scheduler_conf = virtual_server.scheduler
		if virtual_server.scheduler == 'conhash':
			scheduler_conf = '%s --hash-target %s' % (scheduler_conf, virtual_server.scheduler_params)
		execute('ipvsadm -E --%s-service %s:%s -s %s' % (
			virtual_server.protocol, virtual_server.vip, virtual_server.port, scheduler_conf))

	@classmethod
	def add_rs(cls, virtual_server, real_server):
		rs_vni_conf = ''
		if real_server.vni != VNI.UNDERLAY_DEFAULT_VNI:  # sdn network
			rs_vni_conf = 'vni=%s,' % real_server.vni
		execute('ipvsadm -a --%s-service %s:%s -r %s%s:%s -w %s -b' % (
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			rs_vni_conf,
			real_server.ip,
			real_server.port,
			real_server.effective_weight,
		))

	@classmethod
	def del_rs(cls, virtual_server, real_server):
		rs_vni_conf = ''
		if real_server.vni != VNI.UNDERLAY_DEFAULT_VNI:  # sdn network
			rs_vni_conf = 'vni=%s,' % real_server.vni
		execute('ipvsadm -d --%s-service %s:%s -r %s%s:%s' % (
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			rs_vni_conf,
			real_server.ip,
			real_server.port,
		))

	@classmethod
	def set_rs_weight(cls, virtual_server, real_server):
		try:
			rs_vni_conf = ''
			if real_server.vni != VNI.UNDERLAY_DEFAULT_VNI:  # sdn network
				rs_vni_conf = 'vni=%s,' % real_server.vni
			execute('ipvsadm -e --%s-service %s:%s -r %s%s:%s -w %s -b' % (
				virtual_server.protocol,
				virtual_server.vip,
				virtual_server.port,
				rs_vni_conf,
				real_server.ip,
				real_server.port,
				real_server.effective_weight,
			))
		except BaseException as e:
			log.error("set rs weight failed as %s, trackback: %s" % (e, traceback.format_exc()))

	@classmethod
	def update_lip(cls, existing_vs, new_vs, lip_type, cluster_type, nic):
		if lip_type == 'outer_lips':
			existing_vs_lips = existing_vs.outer_lips
			existing_vs_master_lips = existing_vs.master_outer_lips
			new_vs_lips = new_vs.outer_lips
			new_vs_master_lips = new_vs.master_outer_lips

			del_lip = IPVSAdminHelper.del_outer_lip
			add_lip = IPVSAdminHelper.add_outer_lip
			add_slave_lip = IPVSAdminHelper.add_outer_slave_lip
		elif lip_type == 'inner_lips':
			existing_vs_lips = existing_vs.inner_lips
			existing_vs_master_lips = existing_vs.master_inner_lips
			new_vs_lips = new_vs.inner_lips
			new_vs_master_lips = new_vs.master_inner_lips

			del_lip = IPVSAdminHelper.del_inner_lip
			add_lip = IPVSAdminHelper.add_inner_lip
			add_slave_lip = IPVSAdminHelper.add_inner_slave_lip
		else:
			existing_vs_lips = existing_vs.node_lips
			existing_vs_master_lips = existing_vs.master_node_lips
			new_vs_lips = new_vs.node_lips
			new_vs_master_lips = new_vs.master_node_lips

			del_lip = IPVSAdminHelper.del_node_lip
			add_lip = IPVSAdminHelper.add_node_lip
			add_slave_lip = IPVSAdminHelper.add_node_slave_lip

		existing_vs_slave_lips = list(set(existing_vs_lips).difference(set(existing_vs_master_lips)))
		new_vs_slave_lips = list(set(new_vs_lips).difference(set(new_vs_master_lips)))
		# Clear expire slave lip
		for lip in set(existing_vs_slave_lips).difference(set(new_vs_slave_lips)):
			del_lip(lip, new_vs, nic)
			existing_vs_lips.remove(lip)
		# Clear expire master lip
		for lip in set(existing_vs_master_lips).difference(set(new_vs_master_lips)):
			del_lip(lip, new_vs, nic)
			existing_vs_lips.remove(lip)
			existing_vs_master_lips.remove(lip)

		for lip in set(new_vs_lips).difference(set(existing_vs_lips)):
			# standard cluster with sync session.
			if FullnatConfig.IS_STANDARD_CLUSTER:
				if lip in new_vs_master_lips:
					# Add missing master lip.
					add_lip(lip, new_vs, nic)
					existing_vs_master_lips.append(lip)
				else:
					# Add missing slave lip.
					add_slave_lip(lip, new_vs, nic)
			# non-standard cluster without sync session.
			else:
				# Add missing lip.
				add_lip(lip, new_vs, nic)
				existing_vs_master_lips.append(lip)
			existing_vs_lips.append(lip)

	@classmethod
	def add_node_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --add-laddr -z %s --%s-service %s:%s -F %s' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def add_node_slave_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --add-laddr -z %s --%s-service %s:%s -F %s --sync-laddr' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def del_node_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --del-laddr -z %s --%s-service %s:%s -F %s' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		), exit_on_fail=False) # temporary adapt remove node scene, slive lip will be removed

	@classmethod
	def add_inner_lip(cls, lip, virtual_server, nic):
		vni = virtual_server.target_vni
		execute('ipvsadm --add-inner-laddr -z vni=%s,%s --%s-service %s:%s -F %s' % (
			vni,
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def add_inner_slave_lip(cls, lip, virtual_server, nic):
		vni = virtual_server.target_vni
		execute('ipvsadm --add-inner-laddr -z vni=%s,%s --%s-service %s:%s -F %s --sync-laddr' % (
			vni,
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def del_inner_lip(cls, lip, virtual_server, nic):
		# This scene should not happen, cause del inner lip rather than whole virtual server is not supported by dpvs.
		vni = virtual_server.target_vni
		execute('ipvsadm --del-inner-laddr -z vni=%s,%s --%s-service %s:%s -F %s' % (
			vni,
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		), exit_on_fail=False) # temporary adapt remove node scene, slive lip will be removed

	@classmethod
	def add_outer_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --add-outer-laddr -z %s --%s-service %s:%s -F %s' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def add_outer_slave_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --add-outer-laddr -z %s --%s-service %s:%s -F %s --sync-laddr' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		))

	@classmethod
	def del_outer_lip(cls, lip, virtual_server, nic):
		execute('ipvsadm --del-outer-laddr -z %s --%s-service %s:%s -F %s' % (
			lip,
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			nic,
		), exit_on_fail=False) # temporary adapt remove node scene, slive lip will be removed

	@classmethod
	def get_vs_acl_cmd(cls, action, vs, type, cidrs):
		cmd = []
		if len(cidrs) == 0:
			return cmd
		for cidr in cidrs:
			cmd.append('%s %s %s %s' % (action, vs, type, cidr))
		return cmd

	@classmethod
	def batch_update_acl(cls, cmd_lst):
		if len(cmd_lst) == 0:
			return
		tmp_cmd = ''
		# sh arg too long err: https://www.in-ulm.de/~mascheck/various/argmax/, so we execute 1000 item one time 
		for i in range(len(cmd_lst)):
			tmp_cmd += '%s\n' % cmd_lst[i]
			if (i + 1) % 1000 == 0:
				get_command_output_with_lock('echo "%s" | ipvsadm --ensure --restore' % tmp_cmd)
				tmp_cmd = ''
		get_command_output_with_lock('echo "%s" | ipvsadm --ensure --restore' % tmp_cmd)

	@classmethod
	def gather_vs_acl_cmd(cls, ext_vs, new_vs):
		res = []
		vs_cmd = '--%s-service %s:%s' % (ext_vs.protocol,ext_vs.vip,ext_vs.port)
		# Update blacklist
		blk_del_set = set(ext_vs.blacklist).difference(set(new_vs.blacklist))
		res += IPVSAdminHelper.get_vs_acl_cmd('--del-blklst', vs_cmd, '-k', blk_del_set)
		blk_add_set = set(new_vs.blacklist).difference(set(ext_vs.blacklist))
		res += IPVSAdminHelper.get_vs_acl_cmd('--add-blklst', vs_cmd, '-k', blk_add_set)

		# Update whitelist
		wht_del_set = set(ext_vs.whitelist).difference(set(new_vs.whitelist))
		res += IPVSAdminHelper.get_vs_acl_cmd('--del-whtlst', vs_cmd, '-2', wht_del_set)
		wht_add_set = set(new_vs.whitelist).difference(set(ext_vs.whitelist))
		res += IPVSAdminHelper.get_vs_acl_cmd('--add-whtlst', vs_cmd, '-2', wht_add_set)

		return res

	@classmethod
	def update_uoa_trail(cls, uoa_trail, virtual_server):
		return get_command_output_with_lock('ipvsadm -E -u %s:%s --uoa trail=%s' % (
			virtual_server.vip,
			virtual_server.port,
			uoa_trail,
		))
	
	@classmethod
	def update_uoa_mode(cls, uoa_mode, virtual_server):
		if uoa_mode == 1:
			mode = 'ipo'
		elif uoa_mode == 2:
			mode = 'upo'
		else:
			mode = 'opp'
		return get_command_output_with_lock('ipvsadm -E -u %s:%s --uoa mode=%s' % (
			virtual_server.vip,
			virtual_server.port,
			mode,
		))

	@classmethod
	def update_uoa_vip_switch(cls, uoa_vip_switch, virtual_server):
		if not PalShellHelper.ENABLE_UOA_VIP_SWITCH:
			return
		return get_command_output_with_lock('ipvsadm -E -u %s:%s --opt-vip %s' % (
			virtual_server.vip,
			virtual_server.port,
			uoa_vip_switch,
		))

	@classmethod
	def update_toa_vip_switch(cls, toa_vip_switch, virtual_server):
		if not PalShellHelper.ENABLE_TOA_VIP_SWITCH:
			return
		return get_command_output_with_lock('ipvsadm -E -t %s:%s --opt-vip %s' % (
			virtual_server.vip,
			virtual_server.port,
			toa_vip_switch,
		))

	@classmethod
	def update_toa_switch(cls, toa_switch, virtual_server):
		if not PalShellHelper.ENABLE_TOA_SWITCH:
			return
		return get_command_output_with_lock('ipvsadm -E -t %s:%s --toa %s' % (
			virtual_server.vip,
			virtual_server.port,
			toa_switch,
		))

	@classmethod
	def update_mss(cls, mss, virtual_server):
		if not PalShellHelper.ENABLE_MSS:
			return
		return get_command_output_with_lock('ipvsadm -E -t %s:%s --mss %s' % (
			virtual_server.vip,
			virtual_server.port,
			mss,
		))
	
	@classmethod
	def update_connect_exit(cls, exit, virtual_server):
		if not PalShellHelper.ENABLE_CONNECT_EXIT:
			return
		return get_command_output_with_lock('ipvsadm -E --%s-service %s:%s --exit %s' % (
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			exit,
		))

	@classmethod
	def update_eip(cls, eip, virtual_server):
		if not PalShellHelper.ENABLE_EIP:
			return
		return get_command_output_with_lock('ipvsadm -E --%s-service %s:%s --eip %s' % (
			virtual_server.protocol,
			virtual_server.vip,
			virtual_server.port,
			eip,
		))

	@classmethod
	def report_missing_virtual_servers(cls, missing_virtual_servers):
		vs_dicts = []
		for vs in missing_virtual_servers:
			vs_dicts.append(vs.to_dict())
		write_file(cls.MISSING_VS_PATH, json.dumps(vs_dicts))

	@classmethod
	def get_vs_lips(cls, vs):
		lips = []
		for node_lip in vs.node_lips:
			lips.append(IPWithMask(node_lip, vni=VNI.UNDERLAY_DEFAULT_VNI))
		for outer_lip in vs.outer_lips:
			lips.append(IPWithMask(outer_lip, vni=VNI.UNDERLAY_DEFAULT_VNI))
		for inner_lip in vs.inner_lips:
			lips.append(IPWithMask(inner_lip, vni=vs.target_vni))
		return lips
	@classmethod
	def update_qos(cls, vs):
		if not PalShellHelper.ENABLE_QOS_UPDATE:
			return
		return execute('ipvsadm -E --%s-service %s:%s --qos-group-in-bytes %s --qos-group-out-bytes %s --qos-in-bytes %s --qos-out-bytes %s' % (
			vs.protocol,
			vs.vip,
			vs.port,
			vs.qos_group_in,
			vs.qos_group_out,
			vs.qos_in,
			vs.qos_out,
		))


class PalShellHelper:
	def __init__(self):
		pass

	CONFIG_FILE_PATH = '/etc/mesos-dpvs/fullnat.json'
	QOS_CONFIG_FILE_PATH = '/etc/mesos-dpvs/qos.json'
	ENABLE_QOS_UPDATE = True # It will be set as False if dpvs not support qos, restart to reset(to avoid unnecessary error log)
	ENABLE_QOS_DROP = False
	new_qos_config = {} # qos name to qos
	existing_qos_config = {} # qos name to qos
	qos_add_del_ignore_list = []
	MISSING_QOS_NAMES = set()
	ENABLE_UOA_VIP_SWITCH = False
	ENABLE_TOA_VIP_SWITCH = False
	ENABLE_TOA_SWITCH = False
	ENABLE_MSS = False
	ENABLE_CONNECT_EXIT = False
	ENABLE_EIP = False
	STOP_SYNC_REALTIME_SEND = 0
	NIC_PREFIX = ['dpdk', 'bond']

	# add this new class to avoid update FullnatConfig
	class SyncSessionConf:
		def __init__(self, config):
			self.use_dpdk_sync_session = 0
			self.sync_session_src_ip = None
			self.sync_session_dst_ips = []
			self.sync_session_dpdk_src_ip = None
			self.sync_session_dpdk_dst_ips = []
			self.sync_session_port = 0
			# standard cluster default
			self.realtime_send = 1
			self.realtime_recv = 1

			self.__dict__.update(config)

		def to_dict(self):
			return {
				'use_dpdk_sync_session': self.use_dpdk_sync_session,
				'sync_session_src_ip': self.sync_session_src_ip,
				'sync_session_dst_ips': sorted(self.sync_session_dst_ips),
				'sync_session_dpdk_src_ip': self.sync_session_dpdk_src_ip,
				'sync_session_dpdk_dst_ips': sorted(self.sync_session_dpdk_dst_ips),
				'sync_session_port': self.sync_session_port,
				'realtime_send': self.realtime_send,
				'realtime_recv': self.realtime_recv,
			}
	# TODO: class SyncSessionConf整合到class FullnatConfig
	@classmethod
	def load_sync_session(cls):
		content = read_file(cls.CONFIG_FILE_PATH)
		config = json.loads(content)

		return PalShellHelper.SyncSessionConf(config)

	@classmethod
	def get_sync_status(cls):
		sync_status = {}
		output = get_command_output_with_lock('pal-shell sync status')
		# Match
		# 	sync status:
		#		...
		# 		realtime_send: 1
		#		...
		# 		realtime_recv: 1
		#		...
		# 		sync_all_send: 0
		#		...
		# 		sync_all_recv: 0
		#		...
		# 		dpdk_send_mode: 0
		#		...
		# 		local 0.0.0.0:0
		# 		remotes num: 0
		# 		dpdk local 0.0.0.0 00:00:00:00:00:00
		# 		dpdk remotes num: 0
		# Or
		# 	    ...
		# 		remotes num: 1
		# 		[0] 10.129.126.3:6666
		# 		...
		sync_status_pattern = re.compile(
			r'\s*sync status:\s+'
			r'(.*\n)*'
			r'\s*realtime_send: (?P<realtime_send>\d+)\s+'
			r'(.*\n)*'
			r'\s*realtime_recv: (?P<realtime_recv>\d+)\s+'
			r'(.*\n)*'
			r'\s*sync_all_send: (?P<sync_all_send>\d+)\s+'
			r'(.*\n)*'
			r'\s*sync_all_recv: (?P<sync_all_recv>\d+)\s+'
			r'(.*\n)*'
			r'\s*dpdk_send_mode: (?P<dpdk_send_mode>\d+)\s+'
			r'(.*\n)*'
			r'\s*local (?P<sync_session_src_ip>[\.\d]+):(?P<sync_session_port>\d+)\s+'
			r'\s*remotes num: (?P<remotes_num>\d+)\s+')
		match = sync_status_pattern.match(output.split('dpdk local')[0])
		if not match:
			log.error('can not match sync status, output: %s' % output)
			return PalShellHelper.SyncSessionConf(sync_status)

		sync_status['realtime_send'] = int(match.group('realtime_send'))
		sync_status['realtime_recv'] = int(match.group('realtime_recv'))
		sync_status['use_dpdk_sync_session'] = int(match.group('dpdk_send_mode'))
		sync_status['sync_session_src_ip'] = match.group('sync_session_src_ip')
		sync_status['sync_session_port'] = int(match.group('sync_session_port'))
		sync_status['sync_session_dst_ips'] = []
		if int(match.group('remotes_num')) > 0:
			for line in output.split('\tremotes num:')[-1].split('dpdk local')[0].split('\n'):
				remote_node_pattern = re.compile(r'\s*\[\d+\] (?P<ip>[\d\.]+):(?P<port>\d+)\s*')
				remote_node_match = remote_node_pattern.match(line)
				if not remote_node_match:
					continue
				sync_status['sync_session_dst_ips'].append(remote_node_match.group('ip'))

		# get dpdk local and dpdk remote info
		pos_dpdk_local = output.index('dpdk local')
		sub_output = output[pos_dpdk_local:]
		dpdk_sync_status_pattern = re.compile(
			r'dpdk local (?P<ip>[\.\d]+) (?P<mac>([0-9a-fA-F]:?){12})\s+'
			r'dpdk remotes num: (?P<dpdk_remotes_num>\d+)\s+'
		)
		match = dpdk_sync_status_pattern.match(sub_output)
		if not match:
			log.error('can not match dpdk sync status, output: %s' % sub_output)
			return PalShellHelper.SyncSessionConf(sync_status)

		# here store dpdk ip
		sync_status['sync_session_dpdk_src_ip'] = match.group('ip')
		sync_status['sync_session_dpdk_dst_ips'] = []
		if int(match.group('dpdk_remotes_num')) > 0:
			for line in sub_output.split('\tdpdk remotes num:')[-1].split('\n'):
				remote_node_pattern = re.compile(r'\s*\[\d+\] (?P<ip>[\d\.]+) (?P<mac>([0-9a-fA-F]:?){12})\s*')
				remote_node_match = remote_node_pattern.match(line)
				if not remote_node_match:
					continue
				sync_status['sync_session_dpdk_dst_ips'].append(remote_node_match.group('ip'))

		return PalShellHelper.SyncSessionConf(sync_status)

	@classmethod
	def get_dpdk_dst_mac(cls):
		f = os.popen('ip r|grep default')
		ip_info = f.read()
		f.close()
		if not ip_info:
			return '00:00:00:00:00:00'
		ip = ip_info.split('via')[1].split('dev')[0].strip()

		f = os.popen('arp -n|grep ' + ip)
		mac_info = f.read()
		f.close()
		if not mac_info:
			return '00:00:00:00:00:00'

		mac_pattern = re.compile(r'\s*(?P<ip>[\d\.]+)\s*ether\s*(?P<mac>([0-9a-fA-F]:?){12})\s*.')
		mac_match = mac_pattern.match(mac_info)

		return mac_match.group('mac')

	@classmethod
	def get_dpdk_src_mac(cls, src_ip):
		f = os.popen('dpip addr show|grep ' + src_ip)
		ip_info = f.read()
		f.close()
		if not ip_info:
			return '00:00:00:00:00:00'
		nic_name = ip_info.split(' ')[-1].split('\n')[0]

		f = os.popen('dpip link show ' + nic_name)
		mac_infos = f.read()
		f.close()
		if not mac_infos:
			return '00:00:00:00:00:00'

		mac_infos_list = mac_infos.split('\n')
		mac = None
		for line in mac_infos_list:
			mac_pattern = re.compile(r'\s*addr\s*(?P<mac>([0-9a-fA-F]:?){12})\s*.')
			match = mac_pattern.match(line)
			if match:
				mac = match.group('mac')
				break

		if mac:
			return mac
		else:
			return '00:00:00:00:00:00'

	@classmethod
	def update_sync_status(cls, sync_status, existing_sync_status):
		if sync_status is None or existing_sync_status is None:
			return

		is_cmd = 0
		for cmd_path in os.environ['PATH'].split(':'):
			if os.path.isdir(cmd_path) and 'pal-shell' in os.listdir(cmd_path):
				is_cmd = 1
				break
		if is_cmd == 0:
			log.error("didn't find pal-shell in system $PATH")
			return

		if not (sync_status.sync_session_src_ip and sync_status.sync_session_port and sync_status.cluster_type.startswith('standard') and sync_status.sync_session_dpdk_src_ip):
			log.error('invalid sync session conf, sync_session_src_ip: %s, sync_session_port: %s, cluster_type: %s'
			% (sync_status.sync_session_src_ip, sync_status.sync_session_port, sync_status.cluster_type))
			return

		# sync realtime_send/realtime_recv
		new_realtime_send = sync_status.realtime_send if Bird.is_running() else PalShellHelper.STOP_SYNC_REALTIME_SEND
		if new_realtime_send != existing_sync_status.realtime_send:
			log.info('dpvs_realtime_send_mode_updated: %s' % new_realtime_send)
			execute('pal-shell sync realtime_send %s' % new_realtime_send)
		new_realtime_recv = sync_status.realtime_recv
		if new_realtime_recv != existing_sync_status.realtime_recv:
			log.info('dpvs_realtime_recv_mode_updated:%s' % new_realtime_recv)
			execute('pal-shell sync realtime_recv %s' % new_realtime_recv)

		# sync kernel session
		new_sync_session_src_ip = sync_status.sync_session_src_ip
		old_sync_session_src_ip = existing_sync_status.sync_session_src_ip
		new_sync_session_port = sync_status.sync_session_port
		old_sync_session_port = existing_sync_status.sync_session_port
		if new_sync_session_src_ip != old_sync_session_src_ip or \
			new_sync_session_port != old_sync_session_port:
			log.info('dpvs_sync_session_src_addr_updated: %s:%s' % (new_sync_session_src_ip, new_sync_session_port))
			execute('pal-shell sync set_local %s %s' % (
				new_sync_session_src_ip, str(new_sync_session_port)
			))

		new_dst_ips = sync_status.sync_session_dst_ips
		existing_dst_ips = existing_sync_status.sync_session_dst_ips
		# del old remote ips
		for dst_ip in set(existing_dst_ips).difference(set(new_dst_ips)):
			execute('pal-shell sync del_remote %s %s' % (dst_ip, str(old_sync_session_port)))
		# add new remote ips
		for dst_ip in set(new_dst_ips).difference(set(existing_dst_ips)):
			execute('pal-shell sync add_remote %s %s' % (dst_ip, str(new_sync_session_port)))

		# sync dpdk session
		new_sync_session_dpdk_src_ip = sync_status.sync_session_dpdk_src_ip
		src_mac = cls.get_dpdk_src_mac(new_sync_session_dpdk_src_ip)
		if src_mac == '00:00:00:00:00:00':
			log.error('the dpdk_src_mac is 00:00:00:00:00:00')

		if new_sync_session_dpdk_src_ip != existing_sync_status.sync_session_dpdk_src_ip:
			log.info('dpvs_sync_session_dpdk_src_ip_updated:%s' % new_sync_session_dpdk_src_ip)
			execute('pal-shell sync dpdk_set_local %s %s' % (
				new_sync_session_dpdk_src_ip, src_mac
			))

		new_dpdk_dst_ips = sync_status.sync_session_dpdk_dst_ips
		existing_dpdk_dst_ips = existing_sync_status.sync_session_dpdk_dst_ips
		# del old remote ips
		for dst_ip in set(existing_dpdk_dst_ips).difference(set(new_dpdk_dst_ips)):
			execute('pal-shell sync dpdk_del_remote %s' % dst_ip)
		# add new remote ips
		dst_mac = cls.get_dpdk_dst_mac()
		if dst_mac == '00:00:00:00:00:00':
			log.error('the dpdk_dst_mac is 00:00:00:00:00:00')

		for dst_ip in set(new_dpdk_dst_ips).difference(set(existing_dpdk_dst_ips)):
			execute('pal-shell sync dpdk_add_remote %s %s' % (dst_ip, dst_mac))

		return

	@classmethod
	def add_vtep(cls, vtep):
		execute('pal-shell vtep add %s %s %s' % (
			vtep.vni,
			vtep.pod_ip,
			vtep.node_ip,
		))

	@classmethod
	def del_vtep(cls, vtep):
		execute('pal-shell vtep delete %s %s' % (
			vtep.vni,
			vtep.pod_ip,
		))

	@classmethod
	def update_vtep(cls):
		VtepFactory.get_existing_vtep_set()

		if VtepFactory.new_vtep_set == VtepFactory.existing_vtep_set:
			# no change in vtep
			return
		else:
			new_vteps = set()
			missing_vteps = IPVSAdminHelper.MISSING_VTEP
			for new_vtep in VtepFactory.new_vtep_set:
				new_vteps.add("%s,%s" % (new_vtep.vni, new_vtep.pod_ip))
			# 如果发生了pod漂移，需要先删再加
			for vtep in VtepFactory.existing_vtep_set.difference(VtepFactory.new_vtep_set):
				if not PalShellHelper.need_pass_vtep_del(vtep, new_vteps, missing_vteps):
					PalShellHelper.del_vtep(vtep)

			for vtep in VtepFactory.new_vtep_set.difference(VtepFactory.existing_vtep_set):
				PalShellHelper.add_vtep(vtep)

			VtepFactory.existing_vtep_set = VtepFactory.new_vtep_set

	@classmethod
	def need_pass_vtep_del(cls, vtep, new_vteps, missing_vteps):
		vtep_key = "%s,%s" % (vtep.vni, vtep.pod_ip)
		if vtep_key in new_vteps: #node ip需要更新，当前只支持先删后加
			return False
		elif vtep_key in missing_vteps: #node ip不需要更新，且vtep关联了被异常删除的vs，此时跳过删除
			return True
		else: #vtep需要被删除
			return False

	class Qos(object):
		def __init__(self, name, type, policy, cir, eir, cbs='0', ebs='0'):
			self.name = name
			self.type = type
			self.policy = policy
			self.cir = str(cir)
			self.eir = str(eir)
			self.cbs = str(cbs)
			self.ebs = str(ebs)
		@classmethod
		def equal(cls, qos1, qos2):
			# 这里没有对比type，因为暂不支持通过更新操作来更新type
			if (qos1.name, qos1.policy, qos1.cir, qos1.eir, qos1.cbs, qos1.ebs) == (qos2.name, qos2.policy, qos2.cir, qos2.eir, qos2.cbs, qos2.ebs):
				return True
			else:
				return False
	
	@classmethod
	def load_new_qos(cls):
		content = read_file(cls.QOS_CONFIG_FILE_PATH)
		if content == None:
			log.error('%s does not exist' % cls.QOS_CONFIG_FILE_PATH)
			PalShellHelper.ENABLE_QOS_UPDATE = False
			return None

		new_qos_config = {}
		config = json.loads(content)
		for qos_dict in config:
			qos = cls.Qos(
				name = qos_dict['name'],
				type=qos_dict['type'],
				policy=qos_dict['policy'],
				cir = str(qos_dict['cir']),
				eir = str(qos_dict['eir']),
				)
			new_qos_config[qos.name] = qos
		return new_qos_config

	@classmethod
	def load_existing_qos(cls):
		INVALID_SIZE = '-'
		qos_list = get_command_output_with_lock('pal-shell qos show-config', exit_on_fail = False)
		if qos_list == ERROR_RES:
			PalShellHelper.ENABLE_QOS_UPDATE = False
			log.error('run pal-shell qos show failed')
			return None
		output = qos_list.split('\n')
		# 因为不支持cbs、ebs配置的生成，因此暂不进行解析，结果按0算
		# Match 'dpdk1-out-bytes  out-bytes     PASSTHRU  100000000      -    256    256'
		qos_pattern = re.compile(r'\s*(?P<name>\S+)\s+(?P<type>\S+)\s+(?P<policy>\S+)\s+(?P<cir>[0-9\-]+)\s+(?P<eir>[0-9\-]+)')

		qos_config = {}
		for line in output:
			match = qos_pattern.match(line)
			if not match:
				continue

			cir = match.group('cir') if match.group('cir') != INVALID_SIZE else '-1'
			eir = match.group('eir') if match.group('eir') != INVALID_SIZE else '-1'
			qos = cls.Qos(
			name = match.group('name'),
			type=match.group('type'),
			policy=match.group('policy'),
			cir = cir,
			eir = eir,
			)
			qos_config[qos.name] = qos

		qos_drop_status = get_command_output_with_lock('pal-shell qos drop show', exit_on_fail = False)
		qos_drop_pattern = re.compile(r'\s*qos drop:\s*(?P<qos_drop>\S+)\s*')
		output = qos_drop_status.split('\n')
		for line in output:
			match = qos_drop_pattern.match(line)
			if not match:
				continue
			PalShellHelper.ENABLE_QOS_DROP = True if match.group('qos_drop') == 'on' else False

		return qos_config

	@classmethod
	def enable_various_switch(cls):
		result = get_command_output_with_lock('ipvsadm -ln --verbose')
		if result == ERROR_RES:
			return

		output = result.split('\n')
		for line in output:
			toa_pattern = re.compile(r'.*TCP.*toa\s+(?P<toa_switch>\S+).*')
			match_toa_switch = toa_pattern.match(line)
			if match_toa_switch:
				PalShellHelper.ENABLE_TOA_SWITCH = True
				break

		for line in output:
			uoa_pattern = re.compile(r'.*UDP.*uoa-trail\s+(?P<uoa_trail>\d+).*opt-vip\s+(?P<uoa_vip_switch>\S+).*')
			match_uoa_vip_switch = uoa_pattern.match(line)
			if match_uoa_vip_switch:
				PalShellHelper.ENABLE_UOA_VIP_SWITCH = True
				break

		for line in output:
			toa_pattern = re.compile(r'.*TCP.*opt-vip\s+(?P<toa_vip_switch>\S+).*')
			match_toa_vip_switch = toa_pattern.match(line)
			if match_toa_vip_switch:
				PalShellHelper.ENABLE_TOA_VIP_SWITCH = True
				break

		for line in output:
			mss_pattern = re.compile(r'.*TCP.* mss (?P<mss>\d+).*')
			match_mss = mss_pattern.match(line)
			if match_mss:
				PalShellHelper.ENABLE_MSS = True
				break

		for line in output:
			exit_pattern = re.compile(r'.* exit (?P<exit>\d+).*')
			match_exit = exit_pattern.match(line)
			if match_exit:
				PalShellHelper.ENABLE_CONNECT_EXIT = True

			eip_pattern = re.compile(r'.* eip (?P<eip>\d+).*')
			match_eip = eip_pattern.match(line)
			if match_eip:
				PalShellHelper.ENABLE_EIP = True
				break

	@classmethod
	def batch_add_update_qos(cls, config):
		if not PalShellHelper.ENABLE_QOS_UPDATE:
			return
		PalShellHelper.new_qos_config = cls.load_new_qos()
		if PalShellHelper.new_qos_config is None:
			log.error('load new qos config failed')
			return
		PalShellHelper.existing_qos_config = cls.load_existing_qos()
		if PalShellHelper.existing_qos_config is None:
			log.error('load existing qos config failed')
			return
		
		for name, new_qos in PalShellHelper.new_qos_config.items():
			if name in PalShellHelper.existing_qos_config:
				if DPVS.dpvs_version >= Version('24.11.1') and PalShellHelper.is_nic_qos(name):
					# skip update of nic qos
					continue
				existing_qos = PalShellHelper.existing_qos_config[name]
				if PalShellHelper.Qos.equal(new_qos, existing_qos):
					continue
				else:
					PalShellHelper.update_qos(new_qos)
			elif not PalShellHelper.is_nic_qos(new_qos.name):
				PalShellHelper.add_qos(new_qos)
		if config.enable_qos_drop != PalShellHelper.ENABLE_QOS_DROP:
			PalShellHelper.update_qos_drop(config.enable_qos_drop)
		
	@classmethod
	def batch_del_qos(cls):
		if not PalShellHelper.ENABLE_QOS_UPDATE:
			return
		for name, existing_qos in PalShellHelper.existing_qos_config.items():
			if name not in PalShellHelper.new_qos_config and not PalShellHelper.is_nic_qos(name):
				PalShellHelper.del_qos(existing_qos)

	@classmethod
	def add_qos(cls, qos):
		execute('pal-shell qos add %s %s %s %s %s %s %s' % (
			qos.name,
			qos.type,
			qos.policy,
			qos.cir,
			qos.eir,
			qos.cbs,
			qos.ebs,
		))

	@classmethod
	def update_qos(cls, qos):
		execute('pal-shell qos mod %s %s %s %s %s %s' % (
			qos.name,
			qos.policy,
			qos.cir,
			qos.eir,
			qos.cbs,
			qos.ebs,
		))

	@classmethod
	def del_qos(cls, qos):
		if qos.name in PalShellHelper.MISSING_QOS_NAMES:
			return
		execute('pal-shell qos del %s' % (
			qos.name,
		))
	@classmethod
	def update_qos_drop(cls, enable_qos_drop):
		qos_drop = 'on' if enable_qos_drop == True else 'off'
		execute('pal-shell qos drop %s' % (
			qos_drop,
		))
	@classmethod
	def is_nic_qos(cls, qos_name):
		if qos_name in cls.qos_add_del_ignore_list:
			return True
		for p in cls.NIC_PREFIX:
			if qos_name.startswith(p):
				return True

		return False


class Vtep(object):
	FIELD_SEPARATOR = u','

	def __init__(self, vni, pod_ip, node_ip):
		self.vni = str(vni)
		self.pod_ip = pod_ip
		self.node_ip = node_ip

	# overwrite __hash__ and __eq__, if vteps with same fields, they are equal
	def __hash__(self):
		field_list = [self.vni, self.pod_ip, self.node_ip]
		return hash(Vtep.FIELD_SEPARATOR.join(field_list))

	def __eq__(self, other):
		if isinstance(other, self.__class__):
			return (self.vni, self.pod_ip, self.node_ip) == (other.vni, other.pod_ip, other.node_ip)
		else:
			return False

	# https://docs.python.org/2.7/reference/datamodel.html?highlight=hash#object.__ne__
	def __ne__(self, other):
		return not self.__eq__(other)


class VtepFactory(object):
	new_vtep_set = set()
	existing_vtep_set = set()

	@classmethod
	def get_existing_vtep_set(cls):
		output = get_command_output_with_lock('pal-shell vtep show').split('\n')
		vni_pod_node_pattern = re.compile(r'^\s+(?P<vni>\d+)\s+(?P<pod_ip>[\d.]+)\s+(?P<node_ip>[\d.]+)')

		tmp_vtep_list = set()
		for line in output:
			match = vni_pod_node_pattern.match(line)
			if match:
				tmp_vtep_list.add(Vtep(match.group('vni'), match.group('pod_ip'), match.group('node_ip')))

		VtepFactory.existing_vtep_set = tmp_vtep_list

class DPVS(object):

	CTRL_FILE = '/var/run/dpvs_ctrl'
	PID_FILE = '/var/run/dpvs.pid'
	dpvs_version = Version('0') # default minimum version

	def __init__(self):
		self._pid = None
		self.config = get_config()
		self._sync_enabled = True
		self._post_up_finished = False

	def is_up(self):
		# 通过service状态不够准确，所以需要考虑到dpvs实际未启动导致命令下发失败的处理
		return GenericFunction.is_service_active("dpvs")

	def wait_for_up(self):
		log.info('dpvs_status|status=%s', 'waiting to up')

		while not self.is_up():
			time.sleep(self.config.ctrl_poll_interval)

		log.info('dpvs_status|status=%s', 'up')

	def ensure_up(self):
		if not self.is_up():
			self.wait_for_up()

	def reset(self):
		pass

	def post_up(self):
		raise NotImplementedError()

	def run(self):
		raise NotImplementedError()

	def is_restarted(self):
		current_pid = read_file(self.PID_FILE)
		if current_pid is not None:
			current_pid = current_pid.strip()
		if self._pid != current_pid:
			if self._pid:
				log.info('dpvs_restarted|old_pid=%s,new_pid=%s', self._pid, current_pid)
			else:
				log.info('shopee_mesos_dpvs_restarted|current_dpvs_pid=%s', current_pid)
			self._pid = current_pid
			self._post_up_finished = False
			return True
		return False

	def enable_sync(self):
		self._sync_enabled = True
		return self._sync_enabled

	def disable_sync(self):
		self._sync_enabled = False
		return self._sync_enabled

	def run_loop(self):
		while True:
			try:
				self.ensure_up()
				if self.is_restarted():
					self.reset()
					self.post_up()
					self._post_up_finished = True
				if not self._post_up_finished:
					log.error('self.post_up() not finished, shopee-mesos-dpvs quiting')
					exit(-1)
				elif self._sync_enabled:
					self.run()
			except BaseException as e:
				log.error("alert: got dpvs reconcile exception: %s, traceback: %s" % (e, traceback.format_exc()))
				# when dpvs is down, main coroutine should wait at self.ensure_up(); and detecting coroutine(in detector.py) should stop bird without exit(later restart by systemctl) shopee-mesos-dpvs
				time.sleep(self.config.ctrl_poll_interval)
				continue
			time.sleep(self.config.ctrl_poll_interval)


class GetMesosHCMod(object):

	IS_MESOS_WITH_HC = module_config.get_from_local_config("health_check_mod",{}).get("mesos_with_health", False)
	log.info("Init IS_MESOS_WITH_HC to %s", IS_MESOS_WITH_HC)
	@classmethod
	def get_mod(cls):
		check_mod, _ = module_config.get_precise("health_check_mod", {})
		cls.IS_MESOS_WITH_HC = check_mod.get("mesos_with_health", cls.IS_MESOS_WITH_HC)
		log.info("Health Check Mod Configuration Loaded: mesos_with_health = %s", cls.IS_MESOS_WITH_HC)

@click.group()
def cli():
	# Bind cpu.
	psutil.Process().cpu_affinity(
		[psutil.Process().cpu_affinity()[-1]]
	)

	pass
