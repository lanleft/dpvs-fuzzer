#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from gevent import monkey
monkey.patch_all()

import sys

from .logger import log_dir

daemon_log_path = '%s/%s' % (log_dir, 'daemon.log')
sys.stdout = open(daemon_log_path, 'a+')
sys.stderr = open(daemon_log_path, 'a+')

# Register all subcommands
from . import fullnat
from . import snat
from . import base
import sys


class Unbuffered(object):

	def __init__(self, stream):
		self.stream = stream

	def write(self, data):
		self.stream.write(data)
		self.stream.flush()

	def writelines(self, datas):
		self.stream.writelines(datas)
		self.stream.flush()

	def __getattr__(self, attr):
		return getattr(self.stream, attr)


sys.stdout = Unbuffered(sys.stdout)
sys.stderr = Unbuffered(sys.stderr)


if __name__ == '__main__':
	base.cli()
